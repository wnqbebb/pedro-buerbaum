# v01 — «Lo más caro de tu negocio es la invisibilidad» (111,0 s · 720×1280 · 25 fps)

Etiquetas: [O] observado en fotograma · [D] derivado/medido · [I] inferido · [?] desconocido.

**Formato propuesto** (labels.json dice "?"): *clase de pizarra en plano secuencia*. Él de pie ante una pizarra blanca,
cámara en mano, dibuja el argumento mientras lo dice. Justificación: 17 de 27 escenas son `whiteboard` y no hay ningún corte [D].

## Estructura del guion
1. 0–7,6 s · Gancho: «muy poquita gente se da cuenta de qué es lo más caro de su negocio» + dibuja `$`.
2. 7,6–20,5 s · Respuestas falsas (oficina, empleado, software) a cámara.
3. 20,5–23,6 s · Revelación: titular «invisibilidad» → «exposición».
4. 23,6–59,5 s · Problema en pizarra: `CAC ———` (lineal), `MARG > CAC`, flechas de lucha, `↑$` (anuncios más caros).
5. 59,5–73,2 s · Giro a cámara: exponerte (comunidad / marca personal / embajador).
6. 73,2–106,8 s · Solución en pizarra: curva que cae a cero, `M − CAC = B`, `CF`, tacha CAC, nueva fórmula.
7. 106,8–110,6 s · Cierre a cámara («dos formas de competir») y camina hasta tapar la lente. Sin CTA.

## Ritmo
- 27 escenas → 4,1 s/escena [D]. 0 cortes; 7 transiciones físicas (giros/paneos) [D].
- Reencuadre a mano perceptible cada ≈5–6 s (18 movimientos medidos) [D].
- Trazo nuevo en pizarra cada ≈7 s durante los tramos de pizarra (≈12 trazos en 80 s; tiempos ±0,7 s) [D].
- Gráfico digital: 1 solo (20,5–24,0 s, 3,5 s) [O].

## Subtítulos (medido en 13,5 s) [O/D]
- Sans regular/fina blanca (tipo SF Pro/Inter), sin caja ni contorno; altura ≈28–30 px = **2,2 % del alto**.
- Centrado en x; centro a **62,5 % del alto** (pecho/espalda). 1–3 palabras; ≈0,75 s por bloque [D].
- Sin palabra destacada, sin color, sin animación (corte seco). Sigue igual cuando él está de espaldas.

## Titular (20,5–24,0 s) [O]
- Sans bold blanca ≈85–90 % de opacidad, una palabra, ancho ≈66 %, a 22 % del alto, **detrás de la cabeza**.
- Entra con barrido de opacidad izq→der ≈0,4 s; relevo «invisibilidad»→«exposición» a 22,7 s; fundido de salida.

## Paleta, grado y texturas
- Pared/pizarra blanco-azulada (#8E8E93, #A7A3A1), camiseta gris pizarra (#302C32), piel cálida (#8C5034), rotulador azul [O].
- Alta clave, neutro-frío, contraste medio; sin grano, viñeta ni textura añadida [O]. Fondos de tarjeta/negro: no hay.
- Grosor de «icono» = trazo real de rotulador (≈3–5 px en 720 de ancho) [O].

## Sonido
- Suelo en pausas ≈ −30 dB vs voz −17 dB [D]. Música/whoosh: [?] (no audible para este análisis); sin SFX ligados a cortes porque no hay cortes [I].

## Técnicas destacables
1. 2,2–5,0 s · Dibuja `$` al decir «caro»: rompe el busto parlante en el segundo 3.
2. 20,5 s · Único titular digital reservado para la respuesta del gancho; detrás de la cabeza.
3. 30,96 s · Empuje de cámara +15 % en 0,4 s justo al trazar la línea «lineal».
4. 43,3 s · «mayor que» → dibuja `>`; 97,0 s · «me cargo» → tacha CAC (palabra → símbolo).
5. 60,4–61,3 s · Giro de 180° como transición problema→solución, sin corte.
6. 76,3 s · Curva exponencial bajo la línea recta: contraste antes/después en el mismo dibujo.
7. 84,0–88,9 s · Fórmula `M − CAC = B` escrita símbolo a símbolo con la voz.
8. 109,4–110,8 s · Sale tapando la lente (cierre físico).

## Reglas copiables
- Si hay pizarra: una toma, cero cortes; que el cuerpo haga las transiciones.
- Cada término del guion = un trazo; escribe la sigla mientras dices el nombre largo.
- Subtítulo mínimo (2,2 % del alto, 1–3 palabras, 62 % de altura) también de espaldas.
- Un único titular grande por video, para la respuesta; ponlo detrás de la cabeza y semitransparente.
- Vuelve a mirar a cámara en los giros del guion (tesis, solución, cierre); el resto puede ser de espaldas.
- Cierra sin CTA: última frase a cámara y salida física.

**Categorías**: whiteboard 17 · aroll_caption 5 · aroll_punch 3 · aroll_text_overlay 1 · title_cta 1 (sin categorías nuevas).
