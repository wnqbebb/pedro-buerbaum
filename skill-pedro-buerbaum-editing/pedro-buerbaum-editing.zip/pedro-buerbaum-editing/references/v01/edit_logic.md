# v01 — lógica de edición: 10 reglas copiables

[O] observado · [D] derivado · [I] inferido · [?] desconocido. Tiempos ±0,1 s salvo trazos de pizarra (±0,7 s).

1. **Plano secuencia, cero cortes.** 111 s en una sola toma a mano; la diferencia de fotogramas no detecta ningún corte [D].
   Las 7 «transiciones» son paneos o giros del cuerpo (2,3 · 5,9 · 24,9 · 60,6 · 73,3 · 106,6 · 110,2 s) [O].
2. **Palabra → trazo.** Cada concepto se dibuja al nombrarlo: «caro» → `$` (3,0 s); «coste de adquisición» → `CAC` (27,6 s);
   «lineal» → línea recta (31,0 s); «mayor que» → `>` (43,4 s); «más caros» → `↑$` (51,2 s) [O].
3. **Un solo titular digital, para la respuesta.** «invisibilidad» entra a 20,5 s (−0,1 s respecto a la palabra) con barrido
   izq→der de 0,4 s; a 22,7 s se releva por «exposición»; fuera a 24,0 s [O].
4. **Titular detrás de la cabeza y semitransparente.** Sans bold blanca ≈85–90 %, ancho ≈66 %, a 22 % del alto; el pelo tapa
   las últimas letras [O]. No tapa la cara ni compite con el subtítulo.
5. **Subtítulo invariable.** Sans regular blanca ≈2,2 % del alto, 1–3 palabras, centro a 62,5 % del alto, corte seco cada
   ≈0,75 s; idéntico de frente y de espaldas; nunca resalta palabras [O/D].
6. **El empuje de cámara subraya el trazo.** +15 % en 0,4 s a 30,96 s (línea «lineal»); deriva de acercamiento de 1,31→1,57
   entre 39 y 44,5 s mientras escribe `MARG >` [D].
7. **El giro del cuerpo es el corte.** Problema→solución a 60,4–61,3 s («pero sin embargo cuando decides exponerte»):
   se gira y camina hacia cámara con desenfoque de movimiento natural [O].
8. **Contraste en el mismo dibujo.** La curva que cae (76,3 s) se dibuja bajo la línea recta de 31 s; la segunda fórmula
   (≈100 s) bajo la primera `M − CAC = B` (84,0–88,9 s). Antes/después conviven en pantalla [O].
9. **Negar = tachar.** «si me cargo el coste de adquisición» (97,0 s) → tacha `CAC` [I: gesto visible, tachón poco nítido].
10. **Cierre físico sin CTA.** Última frase a cámara (106,9 s) y a 109,4–110,8 s avanza hasta tapar la lente; no hay tarjeta,
    logo ni texto final [O].

## Ritmo [D]
- Eventos por 10 s (triggers + transiciones + movimientos): 5, 3, 6, 5, 4, 1, 5, 4, 4, 3, 4, 1.
- Reencuadre perceptible cada ≈5–6 s; trazo nuevo cada ≈7 s en los tramos de pizarra.

## Lo que NO hay
- Tarjeta, pantalla partida, b-roll, serif itálica, color de acento, texturas, grano: nada de eso aparece [O].
- Música y SFX: [?]. Solo medido el suelo de pausas (≈ −30 dB vs voz −17 dB).

## Rarezas útiles
- Titular único de todo el video y colocado detrás del sujeto.
- Subtítulo flotando sobre la espalda durante ≈80 s sin que moleste: tamaño mínimo y posición fija.
- Saltos de escala de un fotograma a 46,0 s (−12 %) y 49,84 s (−10 %) sin corte visible: posible tirón de zoom o corte
  invisible [D, no verificable a ojo].
