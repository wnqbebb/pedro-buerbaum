# v02 — «La marca personal es un seguro contra la irrelevancia» (59,9 s · 720×1280 · 30 fps)

Etiquetas: [O] observado · [D] derivado/medido · [I] inferido · [?] desconocido.

**Formato propuesto** (labels.json "?"): *tarjeta sobre negro*. Todo el video (A-roll, b-roll y gráficos) vive dentro de una
tarjeta 5:6 de esquinas redondeadas centrada en un lienzo negro. Justificación: la tarjeta no cambia en los 1794 fotogramas [D].

## Estructura del guion
1. 0–4,2 s · Gancho: título «La marca / personal» + tarjeta blanca «contra la / irrelevancia».
2. 4,2–9,8 s · «Imagínate esta escena»: 3 clips de b-roll en blanco y negro (oficina).
3. 9,8–25,5 s · Escenario malo: sin marca personal empieza de cero (A-roll).
4. 25,5–36,9 s · Escenario bueno: reputación, «tiene comunidad / tiene autoridad», «no piden, le piden».
5. 36,9–43,4 s · Idea central en tarjeta blanca: «No depende / de un contrato» (tachado).
6. 43,4–56,2 s · Callback al seguro; puedes perder empleo/cliente/negocio.
7. 56,2–59,4 s · Remate tipográfico «no tiene precio y no desaparece» → negro. Sin CTA.

## Ritmo [D]
- 18 escenas → 3,3 s/escena. 9 cortes, todos secos; 5 de ellos en los primeros 10 s.
- Encuadre de cámara: **no cambia nunca** (trípode, plano medio); tramo más largo sin corte: 9,7–38,8 s (29 s).
- Gráficos/eventos fuertes: 6 en 60 s (uno cada ≈10 s): título 1,0 s · tarjeta blanca 2,8 s · b-roll 5,4 s (0,8+2,0+2,5) ·
  texto grande 2,6 s · tarjeta blanca 4,2 s · titular final 1,7 s.

## Tarjeta (medida en píxeles) [O/D]
- 604×722 px en 720×1280 → **83,9 % del ancho × 56,4 % del alto**, proporción ≈5:6, centrada (x 58–661, y 279–1000).
- Radio de esquina ≈32 px (4,4 % del ancho del lienzo). Fondo **#000000** puro. Sin borde, sombra ni texto alrededor.

## Subtítulos [O/D]
- Sans semibold blanca ≈30 px (**2,3 % del alto**), 1–2 palabras (a veces 3), minúsculas, sin caja.
- Centrado en x; centro a **69,8 % del alto del lienzo** (≈85 % de la altura de la tarjeta, zona de manos).
- No resalta palabras por color. El énfasis se hace **sustituyendo** el subtítulo por un bloque: palabra de apoyo light
  ≈22–28 px + palabra clave bold ≈58–62 px (≈2×), alineado a la izquierda, fundido gris→blanco ≈0,15 s por palabra.
- Ese bloque va en una capa **detrás de las manos** (31,6 s) [O].

## Tarjeta blanca tipográfica (1,5–4,3 s y 38,8–43,0 s) [O]
- Fondo #FFFFFF; texto blanco sobre cajas negras de esquinas rectas; regular ≈36 px + bold ≈50 px.
- Máquina de escribir con asterisco `*` de cursor (≈15 caracteres/s). A 40,9 s garabato fino (≈2 px) que tacha «contrato».

## Paleta, grado, texturas
- A-roll exterior soleado: cielo #D2E7ED, camiseta negra, piel cálida saturada #AF6D4B; contraste medio-alto, sin grano [O].
- B-roll de stock desaturado al 100 % con grano fino [O]. Lienzo negro plano.

## Sonido
- Clic a 1,80 s (tecleo, +0,27 s tras el corte) y a 40,89 s (tachón) según `sfx_events.json` [D].
- Suelo en pausas ≈ −38 dB (mezcla muy limpia) → sin música continua o casi inaudible [I]. Whoosh: [?].

## Técnicas destacables
1. 0,13–0,67 s · Título del tema en grande en el primer medio segundo, luego baja a subtítulo normal.
2. 1,53 s · Inversión a tarjeta blanca con tecleo y cursor `*`.
3. 4,33–9,70 s · Ráfaga de 3 b-rolls b/n para «imagínate esta escena»; vuelta al color en «se queda sin trabajo».
4. 29,9 y 30,8 s · Dos golpes «tiene / comunidad» y «tiene / autoridad» detrás de las manos.
5. 40,9 s · Tachar la palabra negada con clic.
6. 58,0–59,7 s · Remate como titular y corte a negro.

## Reglas copiables
- Tarjeta 84 % × 56 % con radio 32 px sobre #000; nunca pantalla completa.
- Concentra los cortes en los primeros 10 s; después deja 20–30 s de cara.
- Subtítulo 2,3 % del alto, 1–2 palabras; énfasis por tamaño (×2) y peso, no por color.
- Stock ajeno siempre en b/n; el A-roll en color.
- Las frases-tesis van a tarjeta blanca mecanografiada; la palabra descartada se tacha.

**Categorías**: card_video 11 · broll 3 · full_graphic 2 · hook_title 1 · title_cta 1. Nota: `card_video` = A-roll dentro de
la tarjeta (con o sin bloque de texto); `broll` y `full_graphic` también ocurren dentro de la tarjeta (ver `framing`).
