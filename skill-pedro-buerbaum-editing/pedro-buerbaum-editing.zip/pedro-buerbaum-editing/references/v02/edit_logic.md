# v02 — lógica de edición: 10 reglas copiables

[O] observado · [D] derivado · [I] inferido · [?] desconocido. Tiempos ±0,1 s.

1. **Todo dentro de la tarjeta.** 604×722 px (83,9 % × 56,4 %), radio ≈32 px, lienzo #000000; A-roll, b-roll y gráficos
   cambian por corte seco dentro del mismo marco, que nunca se mueve [O/D].
2. **Título en el frame 0.** «La marca» (light, 0,13 s) + «personal» (bold ≈62 px, 0,53–0,67 s) por fundido gris→blanco;
   fuera a 1,0 s y pasa a subtítulo normal [O].
3. **La palabra-problema va sola en blanco.** A 1,53 s corte a tarjeta blanca y tecleo «contra la / irrelevancia»
   (1,73–3,47 s) con cursor `*`; clic a 1,80 s; hold 0,9 s [O/D].
4. **«Imagínate» = b-roll b/n en ráfaga.** 4,33 · 5,13 · 7,17 s: tres clips de 0,8 / 2,0 / 2,5 s (maletín, bolso, portátil),
   desaturados y con grano, con el subtítulo encima [O].
5. **Vuelve al color en el golpe.** A 9,70 s («se queda sin trabajo», −0,1 s antes de la palabra) corte de b/n a él en color [O].
6. **Después, cara.** De 9,7 a 38,8 s no hay cambio de imagen (29 s) salvo un micro jump-cut a 25,73 s [D]: el ritmo lo
   lleva el subtítulo de 1–2 palabras.
7. **Énfasis = sustituir el subtítulo por un bloque ×2.** «tiene / comunidad» (29,9–30,5 s) y «tiene / autoridad»
   (30,8–32,5 s): apoyo light ≈28 px + clave bold ≈62 px, alineado a la izquierda [O].
8. **El texto vive detrás de las manos.** En 31,6 s los dedos pasan por delante de «autoridad»; igual en el remate final [O].
9. **Negar = escribir y tachar.** 38,80 s tarjeta blanca «No depende / de un contrato»; a 40,9 s garabato sobre
   «contrato» con clic (40,89 s); se mantiene 2 s mientras dice la alternativa [O/D].
10. **Remate tipográfico y negro.** «no tiene» 57,95 → «precio» 58,1 → «y no / desaparece» 58,85 s; corte a negro a
    59,67 s (8 fotogramas). Sin CTA [O].

## Ritmo [D]
- Eventos por 10 s: 14, 0, 3, 4, 3, 3 (todo el fuego al principio).
- 9 cortes secos; 0 transiciones con efecto; 0 movimientos de cámara fiables.
- Texto grande en pantalla ≈1,6 s de media.

## Tipografía
- Una sola sans grotesca en light / semibold / bold. Sin serif, sin itálica, sin color de acento [O].
- Subtítulo ≈30 px a 69,8 % del alto; tarjeta blanca: regular ≈36 px + bold ≈50 px en cajas negras.

## Sonido
- Clics de teclado en las dos tarjetas blancas [D, sfx_events.json]. Suelo ≈ −38 dB: sin cama musical apreciable [I].
- Whoosh/golpes en cortes: [?].

## Rarezas útiles
- Cursor de máquina de escribir con asterisco `*`.
- Cajas negras que crecen con el texto (estilo rotuladora) sobre blanco.
- Posible alejamiento −5 % a 30,9–31,2 s al entrar «autoridad» [D, dudoso].
