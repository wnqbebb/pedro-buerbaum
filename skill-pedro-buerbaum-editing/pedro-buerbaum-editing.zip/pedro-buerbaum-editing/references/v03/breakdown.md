# v03 — «El mercado premia más la visibilidad que la sabiduría» (85,0 s · 720×1280 · 30 fps)

Etiquetas: [O] observado · [D] derivado/medido · [I] inferido · [?] desconocido.

**Formato propuesto** (labels.json "?"): *tarjeta sobre negro* (el mismo que v02) en interior cálido, sentado en sofá.
Justificación: tarjeta idéntica en medidas a v02 durante todo el video [D].

## Estructura del guion
1. 0–4,6 s · Gancho de curiosidad («algo que no puedes dejar de ver») sin título.
2. 4,6–11,6 s · Tesis: bloque «el mercado / va a / premiar / más» → tarjeta blanca «visibilidad / que la / sabiduría».
3. 11,6–22,7 s · Ejemplo McDonald's con 2 b-rolls b/n.
4. 22,7–40 s · Regla general: «¿va a ganar siempre en esta carrera?» + b-roll propio en un escenario (8,8 s).
5. 40–65,8 s · El genio que nadie conoce → golpe «va a ser / totalmente / invisible».
6. 65,8–80,4 s · Solución: equilibrio entre desarrollarse y gritarle al mundo.
7. 80,4–84,6 s · Cierre en la última palabra («figura»). Sin CTA.

## Ritmo [D]
- 21 escenas → 4,0 s/escena. 8 cortes secos; 7 antes del segundo 40,2 y **ninguno de 40,2 a 85 s** (45 s).
- Cámara fija; el A-roll cambia de escala solo tras un b-roll (corte oculto a 19,70 s) [I].
- Eventos visuales fuertes: 6 en 85 s (uno cada ≈14 s): bloque 3,1 s · tarjeta blanca 3,9 s · b-roll b/n 4,8 s (2,1+2,7) ·
  bloque 1,6 s · b-roll escenario 8,8 s · bloque 2,2 s.

## Tarjeta [O/D]
- 604×722 px (83,9 % × 56,4 %, ≈5:6), x 58–661, y 279–1000, radio ≈32 px, lienzo #000000, sin borde.

## Subtítulos [O/D]
- Sans semibold blanca ≈30 px (2,3 % del alto), 1–3 palabras, centro a ≈66 % del alto del lienzo (≈79 % de la tarjeta).
- Sin color de acento. Bloques de énfasis en 2–3 niveles alineados a la izquierda en escalera: clave bold 34–62 px,
  apoyo light 18–32 px (a veces gris); fundido gris→blanco ≈0,15–0,2 s por palabra, sincronizado a la voz.
- La imagen se oscurece ligeramente bajo los bloques grandes [O a ojo, no medido].

## Tarjeta blanca (8,27–12,20 s) [O]
- #FFFFFF; tres cajas negras en escalera: «visibilidad» bold ≈62 px · «que la» regular ≈34 px · «sabiduría» bold ≈62 px.
- Tecleo con cursor `*`, cada palabra al decirse (8,33 · 9,8 · 10,3 s); hold 1,1 s.

## Paleta, grado, texturas
- Interior cálido: crema/dorado #E4C48A, #706650, planta verde, camiseta negra #040404; contraste suave, bokeh fuerte [O].
- B-roll ajeno en blanco y negro contrastado; b-roll propio (escenario) en color y clave baja [O]. Sin grano añadido.

## Sonido
- Suelo −37 dB en la tarjeta blanca, hasta −17 dB en otras pausas (probable respiración) [D]. Música y SFX: [?].

## Técnicas destacables
1. 5,2–7,5 s · Frase que se escribe en escalera a la velocidad de la voz y queda en suspenso en «más…».
2. 8,27 s · La respuesta llega con corte a tarjeta blanca.
3. 14,87–19,70 s · Ejemplo de marca ilustrado en b/n (sin colores de marca).
4. 25,5–27,1 s · Afirmación convertida en pregunta escrita.
5. 31,33–40,17 s · B-roll propio en color como prueba de «exponerse».
6. 63,5–65,7 s · «totalmente» enorme e «invisible» en gris tenue: el peso tipográfico significa.
7. 40–85 s · Sin cortes: la retención se confía a la voz, subtítulo y un único golpe tipográfico.

## Reglas copiables
- Mismo marco de tarjeta que v02; cambia solo el contenido.
- Tesis = bloque que se acumula + tarjeta blanca con la comparación.
- Stock ajeno en b/n, material propio en color.
- Esconde los cambios de escala del A-roll detrás de un b-roll.
- Usa peso/opacidad para significar (grande = fuerte, gris fino = débil/invisible).
- Termina en la última palabra, sin negro ni CTA.

**Categorías**: card_video 15 · broll 4 · full_graphic 1 · title_cta 1 (sin `hook_title`: el gancho no lleva título).
