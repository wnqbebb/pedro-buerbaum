# v03 — lógica de edición: 10 reglas copiables

[O] observado · [D] derivado · [I] inferido · [?] desconocido. Tiempos ±0,1 s.

1. **Marco fijo de tarjeta.** 83,9 % × 56,4 %, radio ≈32 px, lienzo #000000; idéntico a v02 [D].
2. **Gancho sin título.** 0–4,6 s solo cara + subtítulo de 1–3 palabras; el texto grande se guarda para la tesis [O].
3. **La tesis se escribe con la voz.** «el mercado» 5,2 s (+0,06) → «va a» 6,0 → «premiar» 6,85 (+0,09) → «más» 7,5 s,
   en escalera y gris→blanco; la frase queda abierta [O].
4. **La respuesta salta a blanco.** Corte a 8,27 s; tecleo «visibilidad» (8,33–9,2), «que la» (9,8), «sabiduría»
   (10,3–11,1) con cursor `*`; vuelve a 12,20 s [O].
5. **Ejemplo de marca en b/n.** «pero es la más vendida» → 14,87 s hamburguesa; 16,97 s nuggets; vuelta a 19,70 s. Dos clips
   de 2,1 y 2,7 s con subtítulo encima [O].
6. **Cambio de escala oculto.** El A-roll vuelve del b-roll (19,70 s) algo más cerrado: el salto no se ve porque hubo
   b-roll en medio [I, comparando hojas].
7. **Pregunta escrita.** «¿va a ganar» 25,5 → «siempre» (gris, 26,2) → «en esta carrera?» 26,6 s; fuera ≈27,1 s [O].
8. **Prueba propia en color y larga.** «exponiéndose ante el mundo» → 31,33 s (−0,2 s) plano general de él en un escenario,
   8,8 s sin cortes internos, hasta 40,17 s [O].
9. **El peso significa.** 63,5 s «va a ser» pequeño · 63,85 s «totalmente» bold ≈62 px · 64,5 s «invisible» light gris que
   no llega a blanco; hold hasta 65,67 s [O].
10. **Segunda mitad sin cortes y final en seco.** De 40,2 a 85,0 s no hay ningún corte; termina en «figura.» sin negro,
    tarjeta ni CTA [O/D].

## Ritmo [D]
- Eventos por 10 s: 7, 10, 4, 2, 2, 0, 3, 0, 1.
- 8 cortes secos; 0 transiciones con efecto. Texto grande ≈2,2 s de media en pantalla.

## Tipografía
- Una sans grotesca en light / semibold / bold; sin serif ni itálica; sin color de acento (solo blanco y gris) [O].
- Subtítulo ≈30 px a 66 % del alto; bloques 34–62 px; tarjeta blanca bold ≈62 px + regular ≈34 px en cajas negras.

## Sonido
- No verificable: música y SFX [?]. Probable tecleo en la tarjeta blanca por analogía con v02 [I].

## Rarezas útiles
- «invisible» escrito casi invisible.
- Oscurecimiento leve del vídeo bajo los bloques grandes [O a ojo].
- Posible alejamiento ≈−5 % a 25,6 s y 63,5 s coincidiendo con los bloques [D, dudoso: puede ser artefacto del texto].
