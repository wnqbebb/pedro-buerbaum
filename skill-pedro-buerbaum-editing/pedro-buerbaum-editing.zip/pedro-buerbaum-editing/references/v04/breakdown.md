# v04 — «Real estate digital: el potencial está en los nichos» (133,7 s · 720×1280 · 25 fps)

Etiquetas: [O] observado · [D] derivado/medido · [I] inferido · [?] desconocido.

**Formato propuesto** (labels.json "?"): *busto parlante con micrófono + titulares ambientales*. Él a pantalla completa tras
una mesa con micro negro, toma única, zoom digital lento y palabras clave grandes detrás de la cabeza.
Justificación: 0 cortes [D]; 17 de 33 escenas son `aroll_caption` y 9 llevan titular.

## Estructura del guion
1. 0–14,1 s · Gancho + metáfora: ser «referente» = tener una parcela de «Real estate digital».
2. 14,1–38,2 s · Nosotros los generalistas = hotel todo incluido; llegamos temprano.
3. 38,2–62,8 s · Hoy es diferente: oportunidad «gigantesca» en los nichos, algoritmos.
4. 62,8–82,9 s · Ejemplo personal: piezas de «Jeep Gladiator» (inserto de él en el Jeep).
5. 82,9–107,2 s · Receta: cliente específico, dolor, oferta, embudo → «modelo / de negocio / escalable».
6. 107,2–125,4 s · Comparación numérica: «50.000» vs «500.000».
7. 125,4–133,0 s · Cierre: «híper especialización», «muy grande». Sin CTA.

## Ritmo [D]
- 33 escenas → 4,0 s/escena. 0 cortes.
- Encuadre: 10 cambios de escala discretos (0,0 · 5,1 · 7,1 · 38,3 · 60,5 · 77,4 · 98,4 · 101,0 · 101,9 · 130,4 s) → uno cada
  **≈13 s**, de 5–18 %; más 4 zooms lentos (3,5–13,5 s) que cubren ≈37 s. Escalas ±3 %.
- Gráficos: 9 titulares + 1 inserto = 10 → uno cada **≈13 s**; duración media **≈2,9 s** (1,25–4,7 s).
  Huecos sin gráfico: 14–48 s y 77–105 s.

## Subtítulos (medido a 4,0 s) [O/D]
- Sans fina/regular blanca ≈34–36 px (**2,7 % del alto**), 1–3 palabras, sin caja.
- Centrado en x; centro a **55,8 % del alto** (filas 695–733), justo sobre la cápsula del micrófono.
- Las letras sobre el micro se ven atenuadas: parece ir detrás del micro o en modo de fusión [I]. Sin palabra destacada.

## Titulares ambientales [O/D]
- Sans grotesca bold color melocotón **≈#DDA778–#E5B384** (medido), altura de x ≈5 % del alto, a 11–19 % del alto,
  **detrás de la cabeza**, con degradado de opacidad (final de palabra más tenue).
- Entran por fundido con barrido izq→der ≈0,3–0,4 s, palabra a palabra; salen por fundido.
- Excepción tipográfica: «Real» en serif itálica fina de alto contraste (12,5 s).
- Cifras con contador ascendente (≈0,9 s) y hold ≈3,6–3,8 s.

## Inserto (75,84–77,3 s) [O]
- Mini-tarjeta vertical ≈20 % del ancho × 17 % del alto, radio ≈14 px, sin borde, arriba-izquierda junto a la cabeza;
  blur-in/blur-out de ≈4 fotogramas. Es la única «tarjeta» del video (no hay video encogido).

## Paleta, grado, texturas
- Cálido y oscuro: pared ámbar #6E4D34 / #4D3826, sombras #100D09, camiseta blanca, micro negro mate, mesa gris cálida [O].
- Contraste medio, viñeta natural suave, sin grano ni textura añadidos [O]. No hay fondos negros ni iconos de línea.

## Sonido
- Suelo en pausas −21 a −35 dB (voz −16 dB) → probable cama musical suave o sala [I]. Whoosh en titulares: [?].

## Técnicas destacables
1. 0,00–0,12 s · Whip zoom-out desenfocado de 3 fotogramas en el frame 0.
2. 2,2 s · «referente» detrás de la cabeza, del color de la pared.
3. 12,5–13,3 s · «Real» (serif itálica) + «estate» + «digital» palabra a palabra.
4. 60,3–60,75 s · Push-in +18 % en «te interesa».
5. 75,84 s · Inserto del Jeep con blur-in, 1,4 s.
6. 104,8–106,6 s · Relevo «modelo» → «de negocio» → «escalable» en el mismo sitio.
7. 113,5 y 120,7 s · Contadores 50.000 / 500.000 en la misma posición.
8. 111–121 s · Push-in lento +10 % durante la comparación numérica.

## Reglas copiables
- Toma única; todo el movimiento es zoom digital ≤18 %.
- Titular de 1 palabra detrás de la cabeza, en el color cálido del fondo, cada ≈13 s y ≈3 s en pantalla.
- Subtítulo 2,7 % del alto a 56 % de altura, sin resaltes.
- Números = contador en el sitio del titular; compara reutilizando la misma posición.
- Reserva la serif itálica para un único término.
- Cierra con titular + punch-in, sin CTA.

**Categorías**: aroll_caption 17 · aroll_text_overlay 8 · aroll_punch 6 · broll 1 (inserto) · title_cta 1.
