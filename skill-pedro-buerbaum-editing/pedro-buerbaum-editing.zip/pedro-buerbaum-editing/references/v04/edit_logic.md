# v04 — lógica de edición: 10 reglas copiables

[O] observado · [D] derivado · [I] inferido · [?] desconocido. Tiempos ±0,1 s; escalas ±3 %.

1. **Toma única, zoom digital.** 134 s sin cortes [D]; todos los cambios de encuadre son zooms animados sobre la misma toma.
2. **Gancho cinético en el frame 0.** Zoom-out desenfocado ≈1,37→1,00 en 0,00–0,12 s (3 fotogramas) [O].
3. **Palabra clave → titular detrás de la cabeza.** «referente» 2,2 s (−0,14) · «gigantesca» 48,2 s (+0,65) ·
   «Jeep Gladiator» 69,2/69,6 s · «híper / especialización» 127,1/128,3 s · «muy grande» 131,9/132,5 s [O].
4. **Color del titular = color de la pared.** Melocotón ≈#DDA778–#E5B384, sans bold, a 11–19 % del alto, con degradado de
   opacidad y tapado por el pelo; parece luz proyectada en la pared [O/D].
5. **Una sola serif itálica.** «Real» (12,5 s) en serif itálica fina + «estate» (12,9) y «digital» (13,3) en sans bold;
   fuera a 14,3 s [O].
6. **Punch-in en los giros del guion.** +7 % en 0,2 s a 38,24 s («permitir. Hoy en día es diferente»); +18 % en 0,45 s
   a 60,3 s («te interesa»); +5 % a 130,4 s (cierre) [D].
7. **Entre golpes, deriva lenta.** Alejamientos lentos de 9,5 y 13,5 s (28–37,5 s y 46–59,5 s) que «cargan» el siguiente
   punch-in; push-in lento +10 % de 111 a 121 s durante las cifras [D].
8. **Prueba en mini-inserto.** «tengo un Jeep Gladiator» → 75,84 s (−0,18) foto redondeada ≈20 % del ancho junto a la
   cabeza, blur-in; fuera a 77,2–77,3 s con zoom-out [O].
9. **Relevo en el mismo sitio.** «modelo» 104,8 → «de negocio» 105,1 → «escalable» 106,1 s; una línea cada vez [O].
10. **Cifras = contador y misma posición.** «50.000» cuenta desde 113,5 s (fijo 114,4; fuera 118,2); «500.000» desde
    120,7 s (fijo 121,6; fuera 125,2). El 40 % (71 s) no recibe gráfico [O].

## Ritmo [D]
- Eventos por 10 s: 7, 4, 1, 2, 2, 0, 3, 5, 0, 1, 6, 2, 2, 4.
- Cambio de escala discreto cada ≈13 s; gráfico cada ≈13 s; duración media de titular ≈2,9 s.
- Huecos sin gráfico de 34 s (14–48) y 28 s (77–105): se sostienen con subtítulo, gesto y deriva de zoom.

## Subtítulo
- Sans fina blanca ≈2,7 % del alto, 1–3 palabras, centro a 55,8 % del alto, corte seco; sin resaltes [O/D].
- Atenuado sobre el micrófono (capa detrás del micro o fusión) [I].

## Sonido
- Suelo −21 a −35 dB en pausas: posible música suave [I]. Whoosh/riser en titulares y punch-ins: [?].

## Rarezas útiles
- Titular con degradado: las últimas letras nunca llegan al 100 %.
- Los titulares aparecen +0,3 a +0,65 s tarde en palabras largas («gigantesca», «escalable», «50.000») y a tiempo en cortas.
- Tres microajustes de zoom seguidos en una lista (98,4 · 100,9 · 101,8 s).
