# v05 — desglose (142.2 s, 720x1280, 25 fps)

Etiquetas: (O) observado en fotogramas · (D) derivado/medido · (I) inferido · (?) desconocido.

**Formato propuesto** (labels.json dice "?"): *busto parlante a mesa + rótulos detrás de la cabeza + 1 pantalla partida con gráfico* (I). Un solo plano continuo: el detector de cortes da 1 plano y no hay ningún corte seco (D). No hay tarjeta redondeada, pizarra, b-roll, serif itálica ni gráfico a pantalla completa (O).

**Guion**: hook-creencia ("la mayoría cree que… una única ventaja", 0–10.8) → definición (10.8–18.3) → giro "es un error" (18.3–23.2) → lista de ventajas: coste por lead (23.2–37.4), llamadas más cortas (37.4–58.6), talento (58.6–66.6), show-up rate (66.6–95.2), oportunidades (95.2–109.4), podcasts/audiencias (109.4–135.4) → cierre con broma, sin CTA (135.4–141.6).

**Ritmo** (D): 39 escenas, 3.6 s/escena. Reparto: aroll_caption 21, aroll_text_overlay 9, aroll_punch 4, split_graphic_top 4, title_cta 1.
- Encuadre: nunca fijo. Deriva lenta (0.92↔1.09) que cambia de sentido cada 4–15 s + 6 punch rápidos con easing (0.12–0.36 s, +4–10 %) en 3.08, 20.48, 45.20, 101.04, 129.96 y un zoom-out rápido en 6.00 → un cambio brusco cada ~20 s, uno de sentido cada ~8 s.
- Gráficos/rótulos: 9 apariciones (8 rótulos + 1 split) → 1 cada ~15 s; duran 1.4–4.7 s (media 2.9 s); el split dura 9.9 s. Valle sin ningún gráfico: 55–95 s.

**Subtítulos** (O/D): sans fina-regular blanca #F8F2F0, ~36 px a 720x1280 (2.8 % del alto; ≈54 px a 1080x1920), sin caja, sin contorno, sin sombra visible; 1–3 palabras (máx. 4: "a la hora de pagar"), una línea, centrados, centro a ~55 % del alto (sobre el pecho, encima del micrófono). Cambian por corte seco, ~0.65 s por bloque. Ninguna palabra resaltada en este video. Cuando la palabra clave está en el rótulo grande, el subtítulo NO la repite. En el split suben a ~37 % del alto (justo bajo el panel). Fuente exacta (?) — familia tipo SF Pro / Inter.

**Rótulo grande** (O/D): sans bold de tracking apretado, minúsculas, ~72–80 px (≈6 % del alto), ancho 60–85 % del cuadro; cifras hasta ~150 px. Color arena #EBB07B (dicho) y #A9815D (por decir). Tercio superior (centro 14–21 % del alto), DETRÁS de la cabeza (máscara del sujeto). Entra blur+fade 0.2–0.3 s y se llena de izq. a der.; sale blur+fade 0.2 s.

**Pantalla partida** (O/D): panel negro #000000 de 0 a 420 px (33 % del alto) con borde inferior difuminado ~25 px, sin radio ni línea; video abajo al 100 % del ancho, reencuadrado abierto (escala 0.70). Gráfico: rótulos sans regular blancos ~22 px, barras redondeadas (radio ~12 px) con degradado gris #9C9C9C→negro, "$" grises, separador vertical ~2 px. Entrada por zoom-blur de 3–4 fr; salida por blur-dissolve de ~5 fr.

**Paleta / grado** (D): pared ámbar #865E3D (luz) → #423324 (sombra), mesa #6E645B, camiseta blanca apagada, micrófono negro; cálido, contraste medio, sin grano añadido (O).

**Sonido** (D, a partir de `audio/no_vocals.wav` y `sfx_events.json` ya presentes en la carpeta): música continua ≈9 dB bajo la voz (−26 vs −17 dBFS) con pulso percusivo regular cada ≈0.58 s (≈103 BPM); golpe grave ('hit/boom') en 0.05 s y en 27.20 s (entrada de la pantalla partida). Whoosh en la salida 37.1: (?).

**Técnicas destacables**
1. 6.00–8.6 — dedo arriba + zoom-out rápido + "1" gigante + "única ventaja" detrás de la cabeza.
2. 18.72 / 20.8 — "error" y vuelta del "1" (callback).
3. 27.04–27.20 — zoom-blur hacia pantalla partida.
4. 27.3–32.5 — gráfico de barras que se construye en el orden del guion ($$$ vs $).
5. 35.2–37.3 — remate "MÁS / RENTABLES" y blur-dissolve a cara.
6. 123.28–124.10 — contador hasta 50.000 + "SEGUIDORES".
7. 130.3–135.0 — línea que se dibuja con dos pestañas "DE NICHO / ANÓNIMO".

**Reglas copiables**
- Subtítulo pequeño, fino, blanco, 1–3 palabras, a 55 % del alto; nunca repite la palabra del rótulo.
- Una palabra/cifra clave por idea → rótulo bold arena detrás de la cabeza, 1.4–4.7 s.
- Zoom lento siempre en marcha; punch con easing (no corte) al abrir idea; zoom-out al gesto grande.
- Datos comparables → panel negro arriba (33 %), él abajo más abierto; construir en orden de la voz.
- Entrar al gráfico con zoom-blur, salir con blur-dissolve.
- Terminar sin rótulo de CTA, alejando el zoom.
