# v05 — lógica de edición (10 reglas copiables)

Formato: busto parlante a mesa con micrófono, 1 solo plano (142 s), 8 rótulos detrás de la cabeza + 1 pantalla partida. (observed salvo donde se indica)

1. **Arranca en seco con la frase, sin título.** 0.00–0.12: asentamiento de zoom 1.19→1.00 en 3 fotogramas; subtítulo desde el fotograma 0.
2. **El zoom nunca se para.** Deriva lenta continua (0.92↔1.09) que cambia de sentido cada 4–15 s: push-in 10.4→14.2, zoom-out 68→83.5, push-in 110→120 (derived).
3. **Punch rápido con easing, nunca corte.** +4–10 % en 0.12–0.36 s al empezar una idea: 3.08, 20.48, 45.20, 101.04, 129.96; y zoom-OUT rápido cuando levanta el dedo (6.00–6.36).
4. **Palabra clave = rótulo grande DETRÁS de la cabeza.** Bold arena #EBB07B, ~6 % del alto, tercio superior; entra con blur+fade 0.2 s y se llena izq→der con la voz: '1 única ventaja' 6.64, 'error' 18.72, '30 min' 51.64, 'show-up rate' 67.6, 'oportunidades' 96.16.
5. **El subtítulo no repite lo que está en grande.** Se queda en la palabra anterior ('tiene' 6.1–8.6; 'El' mientras vive 'show-up rate').
6. **Los rótulos duran 1.4–4.7 s (media 2.9 s)** y salen con blur+fade justo al acabar la frase (10.74, 54.4, 97.6).
7. **Comparación de datos = pantalla partida.** Zoom-blur de 3–4 fr (27.04–27.16) → panel negro 33 % arriba, él abajo más abierto (0.70), subtítulo sube a ~37 % del alto. El gráfico se construye en el orden en que lo dice: barra alta + $$$ (27.3–28.5) → 'Con marca personal' (30.0) → barra baja (31.2) → $ (32.3).
8. **Remate en mayúsculas dentro del mismo panel** ('MÁS / RENTABLES', 35.2–37.1) y salida por blur-dissolve a cara (37.08–37.32).
9. **Cifra = contador que rueda** (34.797→50.000 en 0.85 s, 123.28–124.10) con etiqueta pequeña en mayúsculas debajo.
10. **A/B final = dos pestañas sobre una línea que se dibuja** ('ANÓNIMO' 130.9 → 'DE NICHO' 131.6, la buena más brillante).

Ritmo (derived): eventos por 10 s = ver `rhythm.events_per_10s`; 1 gráfico/rótulo cada ~15 s de media, con un valle 55–95 s sin ninguno.
Audio (derived de `audio/no_vocals.wav` + `sfx_events.json`): música ≈9 dB bajo la voz con pulso cada ≈0.58 s (≈103 BPM); golpe grave en 0.05 s y en 27.20 s (entrada del split). Resto de SFX desconocido.
No hay: tarjeta redondeada, serif itálica, pizarra, b-roll, cortes secos, CTA final.
