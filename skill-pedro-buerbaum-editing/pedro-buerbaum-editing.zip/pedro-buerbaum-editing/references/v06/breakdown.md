# v06 — desglose (115.4 s, 720x1280, 25 fps)

Etiquetas: (O) observado · (D) derivado/medido · (I) inferido · (?) desconocido.

**Formato propuesto** (labels.json "?"): *busto parlante a mesa + rótulos/logos detrás de la cabeza + tarjetas de vídeo + pantalla partida con lista numerada* (I). Un solo plano continuo, 0 cortes secos (D). No hay video encogido en tarjeta, pizarra, serif itálica ni gráfico a pantalla completa (O).

**Guion**: hook-objeción ("me hace gracia la gente que me dice… marca personal", 0–5.8) → respuesta ("ya tienes marca personal", te buscan en LinkedIn/Instagram/Google, 5.8–23.6) → qué NO es (bailecitos, ridículo, influencer, 23.6–30.8) → qué SÍ es: lista de 4 puntos (30.8–53.9) → palanca exponencial (1 minuto → miles de horas, 53.9–70.7) → proceso conectar→confiar→entender→clientes→oferta A→B→ecosistema (70.7–93.4) → resultado: modelo hiperescalable y activo (93.4–111.8) → eslogan "ventaja injusta", sin CTA (111.8–115).

**Ritmo** (D): 34 escenas, 3.4 s/escena. Reparto: aroll_caption 12, aroll_text_overlay 11, split_graphic_top 4, aroll_punch 3, broll 2, hook_title 1, title_cta 1.
- Encuadre: deriva lenta continua (0.92↔1.10) + 10 punch rápidos con easing (0.16–0.4 s, +4–11 %) en 2.32, 6.76, 22.16, 37.76, 59.20, 74.08, 90.96, 102.48, 114.04 (y zoom-out rápidos 6.16, 24.52, 30.32) → cambio brusco cada ~9–11 s.
- Gráficos: 15 apariciones (12 rótulos/logos/diagrama + tarjetas + split) → 1 cada ~7.5 s; rótulos 1.1–4.8 s (media ≈2.6 s); tarjetas 4.6 s; split 14.4 s (4 ítems de 2.1–4.6 s).

**Subtítulos** (O/D): sans fina-regular blanca #F8F2F0, ~36 px a 720x1280 (2.8 % del alto), sin caja/contorno, 1–3 palabras en una línea, centro a ~54.5 % del alto; corte seco, ~0.7 s por bloque. Resalte: una sola vez, 'influencer' (28.42) en BOLD y ~48 px (1.35×), mismo blanco. Sin subtítulo en pausas ('Nada' 30.8–31.7; 101.6–103.5). En el split: centro ~39.6 % del alto, justo bajo el panel.

**Rótulo grande** (O/D): sans bold apretada, minúsculas, ~76–84 px (≈6 % del alto), arena #EBB07B / #A9815D, tercio superior (13–21 %), detrás de la cabeza; blur+fade 0.2–0.3 s de entrada y salida, relleno izq→der. Variantes: comillas (“Marca personal”), 2 líneas ('hiper / escalable'), 2 líneas escalonadas ('ventaja / injusta'), relevo de palabras ('tu producto'→'servicio').

**Logos y diagrama** (O/D): logos monocromos arena ~110 px (LinkedIn relleno, Instagram contorno ~5 px, G de Google); diagrama A···>B con círculos ⌀≈150 px y línea ~2 px, puntos + flecha.

**Tarjetas de vídeo (b-roll)** (O/D): 2 clips verticales ≈230×410 px (32 % × 32 %), radio ~24 px, sin borde, y≈9–41 % del alto, detrás de la cabeza; fade de entrada, blur de salida.

**Pantalla partida** (O/D): panel negro #000000 0–468 px (36.6 % del alto), borde difuminado ~25 px; video abajo 100 % del ancho, escala ~0.75. Titular 2 líneas a la izquierda (regular + bold, ~58 px, 4.5 % del alto, blanco #F6F6F6), número '1.'–'4.' ~22 px, iconos de línea ~2 px. Entrada zoom-blur 3 fr; cambios de ítem con slide+blur a la izquierda y letras en cascada; salida blur-dissolve ~6 fr.

**Paleta / grado** (D): pared ámbar #865E3D→#423324, mesa #6E645B, camiseta blanca, micro negro; cálido, sin grano añadido (O).

**Sonido** (I): cama continua bajo la voz (huecos ≈−25/−30 dBFS); subida de energía sin voz en 101.6–103.5 (posible riser antes de 'hiperescalable'). SFX concretos (?).

**Técnicas destacables**
1. 4.48 — título entrecomillado en el hook.
2. 6.16–6.92 — rebote de zoom en "A ver".
3. 14.36–17.1 — tres logos que se relevan.
4. 25.84–30.48 — dos tarjetas de vídeo detrás de la cabeza + 'influencer' en bold.
5. 39.2–53.9 — lista 1–4 en panel con iconos de línea y slide entre ítems.
6. 88.6–93.7 — diagrama A→B trazado + 'ecosistema'.
7. 101.6–106.2 — pausa, punch y 'hiper / escalable' adelantado.
8. 113.04→fin — eslogan 'ventaja / injusta' como último fotograma.

**Reglas copiables**
- Algo nuevo arriba cada ≤9 s; nunca dos recursos iguales seguidos (texto → logos → tarjetas → lista → diagrama).
- Enumeraciones: un elemento por palabra, sustituyéndose en el mismo punto.
- Listas: panel negro con plantilla fija y solo cambia el icono.
- Resaltar subtítulo con peso y tamaño, no con color.
- Pausa del orador = pantalla sin subtítulo + rótulo que se adelanta.
- Cerrar con el eslogan en grande, sin CTA.
