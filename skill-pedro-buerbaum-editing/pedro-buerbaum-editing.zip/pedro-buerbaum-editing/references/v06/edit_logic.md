# v06 — lógica de edición (10 reglas copiables)

Busto parlante a mesa, 1 plano (115.4 s). 12 rótulos/elementos detrás de la cabeza, 2 tarjetas de vídeo, 1 pantalla partida con lista 1–4. (observed salvo indicación)

1. **Título del tema entre comillas en el hook.** “Marca / personal” 4.48–5.8 detrás de la cabeza mientras imita la objeción; punch-in previo 2.32–2.56.
2. **Rebote de zoom para la pausa cómica.** 'A ver': 1.05→0.95 (6.16–6.76) y vuelta 0.95→1.05 en 4 fr (6.76–6.92) (derived).
3. **Enumeración de marcas = logos monocromos que se relevan.** LinkedIn 14.36 → Instagram 15.64 → Google 16.28, mismo punto, color arena (no colores de marca), ~0.9 s cada uno.
4. **B-roll irónico en tarjetas detrás de él.** Dos clips verticales 32 % × 32 %, radio ~24 px, a los lados de la cabeza: entra uno por palabra ('bailecitos' 25.84, 'ridículo' 27.1) y salen juntos con blur 30.36–30.48.
5. **Resaltar en el subtítulo = bold + ~1.35× tamaño, nunca color.** Solo una vez: 'influencer' 28.42.
6. **Palabra sola + silencio de subtítulo.** 'Nada' 30.84–31.9 sin subtítulo debajo.
7. **Lista = pantalla partida con plantilla fija.** Zoom-blur 39.20–39.28 → panel negro 36.6 %; 'N.' pequeño + titular 2 líneas (regular/bold) alineado a la izquierda + icono de línea fina. Cambio de ítem: slide a la izquierda con blur + letras en cascada (41.24, 44.5, 49.4), adelantado 0.15–0.5 s a la voz. Salida blur-dissolve 53.6–54.0.
8. **Relevo de palabras en el mismo sitio.** 'tu producto' 76.88 → 'servicio' 78.2; 'tus clientes' 84.0 → 'tu oferta' 86.6: el subtítulo se queda en conectores ('tu', 'o', 'en').
9. **Metáfora = diagrama trazado.** Círculo A (88.6) → puntos+flecha → círculo B (90.2) → se suma 'ecosistema' (92.1) con punch 90.96.
10. **Clímax: pausa + punch + rótulo adelantado.** Silencio 101.6–103.5 sin subtítulo; punch 102.48; 'hiper / escalable' 102.96 (0.56 s antes de la palabra). Cierre con eslogan en pantalla ('ventaja / injusta' 113.04→fin), sin CTA.

Ritmo (derived): algo nuevo arriba cada ≤9 s; punch rápido cada ~11 s; rótulos 1.1–4.8 s (media ≈2.6 s).
Audio (inferred): cama continua bajo la voz; posible riser en la pausa de 101.6–103.5; SFX no verificables.
No hay: tarjeta con el video encogido, serif itálica, pizarra, gráfico a pantalla completa, cortes secos.
