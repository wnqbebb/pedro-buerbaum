# v07 — desglose (82.4 s, 720x1280, 25 fps)

Etiquetas: (O) observado · (D) derivado/medido · (I) inferido · (?) desconocido.

**Formato propuesto** (labels.json "?"): *busto parlante a mesa, versión mínima: solo subtítulo fino + rótulos detrás de la cabeza + un diagrama de línea* (I). Un solo plano continuo, 0 cortes secos (D). No hay pantalla partida, tarjeta, pizarra, b-roll, serif itálica ni gráfico sobre negro (O).

**Guion**: hook polémico ("el concepto de marca personal está absolutamente prostituido", 0–6.6) → problema (las redes solo hablan de creación de contenido, 6.6–18) → concesión (el contenido es materia prima / alcance, 18–23.8) → tesis (audiencia de calidad es otra cosa, 23.8–32.1) → definición (posicionarte, dolor y objeciones, 32.1–41.4) → cadena de efectos (aprenden, confían, vehículo A→B, 41.4–62.4) → promesa de la oferta y ecosistema (62.4–72.1) → cierre (más complejo, sofisticado, divertido; nada que ver, 72.1–82.1). Sin CTA.

**Ritmo** (D): 23 escenas, 3.6 s/escena. Reparto: aroll_caption 11, aroll_text_overlay 9, aroll_punch 1, hook_title 1, title_cta 1.
- Encuadre: deriva lenta continua (0.92↔1.10). Cambios rápidos: zoom-out 6.56 y 32.12, punch-in 22.28, 37.48 y 58.20 → uno cada ~16 s; cambios de sentido de la deriva cada ~5–11 s.
- Rótulos: 8 bloques (13 palabras/elementos) → 1 cada ~10 s; 1.3–4.8 s (media ≈2.9 s); ocupan ≈32 % del tiempo. Valle sin nada arriba: 41.1–57.7 s.

**Subtítulos** (O/D): sans fina-regular blanca #F8F2F0, ~36 px a 720x1280 (2.8 % del alto), sin caja/contorno, 1–3 palabras en una línea, centro a ~55.8 % del alto (sobre el micrófono); corte seco; ~0.8 s por bloque. Ninguna palabra resaltada. Se congelan durante pausas ('absolutamente' 1.7–6.6; 'Pero' 24.2–26.1) y no repiten la palabra del rótulo. La transcripción automática falla en "Damas y caballeros" (O: el subtítulo lo pone bien).

**Rótulo grande** (O/D): sans bold apretada, minúsculas, ~72–80 px (≈6 % del alto), arena #E2B284–#EBB07B (dicho) / #A9815D (por decir), centro 17–19 % del alto, detrás de la cabeza. Entradas: blur+fade 0.15–0.3 s con relleno izq→der; write-on letra a letra para 'prostituido'; relevo de palabras sueltas; 2 líneas alineadas a la izquierda para 'promesa / de tu oferta'. Salidas: blur+fade ~0.2 s.

**Diagrama** (O/D): círculos ⌀≈150 px (20 % del ancho) con 'A'/'B' sans regular, 8 puntos + punta de flecha, línea ~2 px arena, banda a 13–24 % del alto.

**Paleta / grado** (D): pared ámbar #865E3D→#423324, mesa #6E645B, camiseta blanca, micro negro; cálido, sin grano añadido (O).

**Sonido** (I): cama continua bajo la voz (huecos ≈−26/−31 dBFS, voz −16.5 dBFS). SFX (?).

**Técnicas destacables**
1. 0.82–2.72 — 'marca personal' como título del hook.
2. 4.24–6.68 — 'prostituido' letra a letra con subtítulo congelado.
3. 6.56–6.76 — zoom-out que cierra el hook.
4. 14.88–18.2 — 'creación → de → contenido'.
5. 37.48–41.1 — 'dolor' + 'objeciones' con jerarquía por tamaño.
6. 57.66–62.4 — diagrama A···>B + dedos caminando.
7. 62.7–65.6 — 'promesa / de tu oferta' sustituye al diagrama.
8. 75.4–78.3 — 'complejo → sofisticado → divertido'.

**Reglas copiables**
- Título del tema detrás de la cabeza antes del segundo 1.
- Palabra polémica: write-on lento y subtítulo congelado.
- Un rótulo por idea, 1–3 palabras, 1.3–4.8 s; el subtítulo nunca lo duplica.
- Tríadas y frases lentas: relevo de palabras en el mismo punto.
- Metáforas espaciales: diagrama de línea fina trazado al ritmo de la voz.
- Si no hay gráfico, que al menos el zoom lento se mueva; cierre sin CTA.
