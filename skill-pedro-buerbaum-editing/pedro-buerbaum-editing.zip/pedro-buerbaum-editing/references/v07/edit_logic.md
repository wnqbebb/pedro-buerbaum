# v07 — lógica de edición (10 reglas copiables)

Busto parlante a mesa, 1 plano (82.4 s). Solo subtítulo fino + rótulos arena detrás de la cabeza + 1 diagrama. (observed salvo indicación)

1. **Tema rotulado en el primer segundo.** 'marca personal' detrás de la cabeza a 0.82 (sale 2.72); zoom de asentamiento 1.11→1.00 en 3 fr.
2. **La palabra más fuerte se escribe letra a letra.** 'prostituido' 4.24→6.0 (≈1.8 s) mientras el subtítulo se queda en 'absolutamente'; punch suave previo 2.4–3.0.
3. **Fin del hook = abrir plano.** Zoom-out 1.04→0.96 en 5 fr (6.56–6.76) al mismo tiempo que el rótulo sale con blur.
4. **Frase clave dicha despacio = relevo de palabras sueltas en grande.** 'creación' 14.88 → 'de' 16.2 → 'contenido' 16.6; el subtítulo ('sobre') incluso se desvanece.
5. **El subtítulo no repite el rótulo**: 'para tener' mientras arriba pone 'alcance' (23.22); 'más' mientras arriba pasan los adjetivos (75.4–78.3).
6. **Definición = verbo rotulado + zoom-out.** 'posicionarte' 32.9–35.7 con zoom-out 32.12–32.40.
7. **Dos conceptos en pareja con jerarquía.** 'dolor' (37.56, derecha) → entra 'objeciones' grande a la izquierda (38.72) y 'dolor' se encoge y se atenúa; punch 37.48.
8. **Metáfora = diagrama trazado detrás de la cabeza.** Círculo A 57.66 → punch 58.20 → puntos+flecha 58.6 → B 59.2–59.6; se mantiene mientras 'camina' con los dedos (60.3–62.4).
9. **El diagrama se releva por el concepto.** A→B sale con blur y entra 'promesa / de tu oferta' en 2 líneas (62.7–65.6).
10. **Valles sin gráficos permitidos** si el zoom lento sigue (41.1–57.7 s: 16.6 s solo cara) y **cierre sin CTA** alejando el zoom (67.4→fin, 1.10→0.92).

Ritmo (derived): rótulos ≈32 % del tiempo, 1.3–4.8 s cada uno; punch rápido cada ~16 s.
Audio (inferred): cama continua bajo la voz; SFX no verificables.
No hay: pantalla partida, tarjeta, serif itálica, pizarra, b-roll, gráfico a pantalla completa, cortes secos.
