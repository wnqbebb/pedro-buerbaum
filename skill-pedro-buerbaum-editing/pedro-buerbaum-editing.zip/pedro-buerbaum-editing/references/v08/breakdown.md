# v08 — desglose (79.8 s, 720x1280, 25 fps)

Etiquetas: (O) observado · (D) derivado/medido · (I) inferido · (?) desconocido.

**Formato propuesto** (labels.json "?"): *busto parlante a mesa + rótulos detrás de la cabeza + un gráfico de números a pantalla completa sobre negro* (I). Dos tomas del mismo set: único corte en 37.32, tapado con una fuga de luz (O/D). No hay pantalla partida, tarjeta, pizarra, b-roll ni serif itálica (O).

**Guion**: hook condicional ("si tienes una marca personal bien posicionada… escúchame", 0–5.9) → tesis negativa (olvídate del low ticket, 5.9–12.4) → por qué (conciencia 2027, acceso, IA, 12.4–32) → solución (High Ticket con implementación, 32–42) → prueba matemática (300.000€ = 3.000 × 100 vs 30 × 10.000, 42–54.4) → dramatización (10.000 personas por el carrito, 54.4–60.7) → segundo argumento (sin compromiso, sin casos de éxito, 60.7–74.3) → sentencia "absolutamente nada" (74.3–79.5). Sin CTA.

**Ritmo** (D): 24 escenas, 3.3 s/escena. Reparto: aroll_caption 11, aroll_text_overlay 6, full_graphic 3, aroll_punch 2, hook_title 1, title_cta 1.
- Encuadre: deriva lenta (1.00↔1.13) + 5 punch rápidos (3.92: +13 % en 0.28 s; 32.04: +5 % en 0.08 s; 37.32: +13 % por corte; 58.32: +7 %; 75.16: +7 % en dos pasos) y un zoom-out rápido (35.72) → cambio brusco cada ~13 s.
- Gráficos: 8 rótulos (1.3–5.0 s, media ≈2.8 s) + 1 gráfico completo de 11.9 s en 9 pasos → un recurso nuevo cada ~8 s. Tramo sin recursos: 60.7–72.5 s.

**Subtítulos** (O/D): sans fina-regular blanca #F8F2F0, ~36 px a 720x1280 (2.8 % del alto), sin caja/contorno, 1–3 palabras, una línea, centro a ~54.4 % del alto; corte seco; ~0.75 s por bloque. Resalte: bold + ~1.35× (≈48–50 px), mismo blanco, 4 veces: 'información' (27.66), '10,000' (54.5), 'caso de éxito' (72.54), 'testimonio' (73.58). Usan símbolos ('o 50 $'). No repiten la palabra del rótulo. Durante el gráfico completo NO hay subtítulo.

**Rótulo grande** (O/D): sans bold apretada ~72–90 px (≈6–7 % del alto), arena #EBB07B / #A9815D, centro 12–19 % del alto, detrás de la cabeza; blur+fade 0.15–0.3 s, relleno izq→der. Variantes: mayúscula inicial ('Escúchame', 'High Ticket'), cifra ('2027'), cifra + etiqueta regular pequeña ('10 000 / personas'), 2 líneas con jerarquía ('absolutamente' ~48 px / 'nada' ~84 px), texto + 4 iconos de línea ~3 px ('inteligencia / artificial').

**Gráfico a pantalla completa** (O/D): fondo #000000 con motas tenues; bloque centrado en 27–52 % del alto; '300.000€' bold ~92 px gris claro #D5D5D5 (ancho ≈65 %); 'FACTURACIÓN TOTAL' regular mayúsculas ~30 px; divisoria ~1–2 px (ancho ≈66 %); fila de factores bold ~44 px con etiquetas mayúsculas ~22 px. Entrada: blur→negro 5 fr + contador 0.6 s; cada pieza con blur-in al decirse; cambio de fila con blur; salida blur→negro→A-roll ~8 fr.

**Paleta / grado** (D): pared ámbar #865E3D→#423324, mesa #6E645B, camiseta blanca, micro negro; cálido; sin grano añadido salvo las motas del gráfico negro (O).

**Sonido** (I): cama continua bajo la voz (huecos ≈−21/−27 dBFS). Picos de agudos junto al flash (37.1) y a la entrada/salida del gráfico (42.4, 54.4): posible whoosh, (?) no verificable.

**Técnicas destacables**
1. 0.62 — 'marca personal' como título del hook.
2. 3.92–4.52 — punch 1.13 + 'Escúchame'.
3. 24.3–29.0 — 'inteligencia artificial' con 4 iconos escalonados.
4. 35.72–37.32 — 'High Ticket' + fuga de luz que tapa el corte.
5. 42.36–43.16 — blur a negro + contador a 300.000€.
6. 44.0–52.2 — ecuación que se arma y cambia una fila.
7. 54.5 / 58.4 — '10.000' repetido en subtítulo bold y en rótulo.
8. 72.54–73.9 — subtítulos bold 'caso de éxito' / 'testimonio'; 74.5 — 'absolutamente / nada'.

**Reglas copiables**
- Segundo gancho a los ~4 s: orden directa + el punch más grande.
- Números con cuenta → pantalla negra completa, sin cara ni subtítulo, pieza por pieza.
- Comparar cambiando una sola línea del gráfico.
- Repetir la cifra clave con tres recursos distintos.
- Resaltar subtítulos con bold + tamaño, no color.
- Tapar cortes de toma con fuga de luz; cerrar con sentencia en pantalla, sin CTA.
