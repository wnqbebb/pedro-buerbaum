# v08 — lógica de edición (10 reglas copiables)

Busto parlante a mesa, 2 tomas (corte en 37.32) (79.8 s). 8 rótulos detrás de la cabeza, 1 gráfico a pantalla completa, 4 subtítulos en bold. (observed salvo indicación)

1. **Tema rotulado en el primer segundo.** 'marca personal' 0.62–1.9 detrás de la cabeza; zoom de asentamiento 1.18→1.00 (4 fr).
2. **Segundo gancho a los 4 s con el punch más fuerte.** 'Escúchame': 1.00→1.13 en 0.28 s (3.92–4.20) + rótulo 4.36; después el plano se abre lento 11 s.
3. **Nombrar al enemigo y la solución en grande.** 'low ticket' 6.4–9.5; 'High Ticket' 35.84–37.1 (con mayúsculas iniciales).
4. **Cifras sueltas = número gigante detrás de la cabeza.** '2027' 15.0–17.6; '10 000 / personas' 58.4–60.6.
5. **Concepto con marcas conocidas = texto + iconos de línea escalonados.** 'inteligencia / artificial' + 4 iconos, uno cada ~0.3 s (24.3–25.7), 4.7 s en pantalla.
6. **Resaltar en el subtítulo con bold + ~1.35× tamaño (sin color).** 'información' 27.66, '10,000' 54.5, 'caso de éxito' 72.54, 'testimonio' 73.58.
7. **Corte de toma escondido con fuga de luz.** Flash cálido 37.04–37.28 sobre el corte (37.32); la toma nueva entra más cerrada (1.15).
8. **Matemática = gráfico a pantalla completa sobre negro, sin cara ni subtítulo.** Entrada blur→negro 42.36–42.56; contador a 300.000€ (42.60–43.16); etiqueta, línea, '3.000 € TICKET' (44.3), 'x' (45.3), '100 CLIENTES' (46.9): cada pieza al decirse.
9. **Comparar cambiando solo una fila.** 49.7–52.2: sale '3.000 € x 100', entra '30 € x 10.000'; el total no se mueve. Salida blur→negro→A-roll 54.28–54.60.
10. **Repetir el dato clave tres veces con tres recursos** (gráfico 52.2 → subtítulo bold 54.5 → rótulo 58.4) y **cerrar con sentencia en pantalla** ('absolutamente / nada', 74.5→fin, punch 75.16–75.8), sin CTA.

Ritmo (derived): recurso nuevo cada ~8 s; gráfico completo 11.9 s en 9 pasos (~1.3 s/paso); punch rápido cada ~16 s.
Audio (inferred): cama continua bajo la voz; posibles whoosh en 37.1, 42.4 y 54.4 (no verificable).
No hay: pantalla partida, tarjeta, serif itálica, pizarra, b-roll.
