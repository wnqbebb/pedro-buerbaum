# v09 — «Esto es como hacer OnlyFans…» (87,0 s, 1080×1920, 25 fps)
**Formato propuesto** (labels.json = "?"): `busto_parlante_mesa_micro + diagrama_split` — monólogo a cámara en mesa con micro, con un bloque de pantalla partida (gráfico sobre negro arriba / él abajo). Justificación: 70 s de A-roll a pantalla completa + 17 s de split.

## Estructura del guion
1. **Hook 0–4,5 s** comparación provocadora + logo OnlyFans detrás.
2. **Cómo lo hacen ellas 4,5–21,5 s** (split con diagrama: contenido → embudo → plataforma → servicios).
3. **Pregunta puente 21,6–29 s** «¿Puedes hacerlo tú? Sí. ¿Cómo?».
4. **Método 29–47 s**: oferta de valor real → funnel de ventas → atención y autoridad.
5. **Insight 47–77,8 s**: la atención se compra, la autoridad se construye.
6. **CTA 77,8–87 s**: «Comenta la palabra autoridad».

## Ritmo (derivado)
- 27 escenas → 3,2 s/escena. Subtítulo nuevo cada ≈ 0,4–0,7 s.
- Cambio de encuadre: 6 saltos de escala en 70 s de A-roll (uno cada ≈ 11 s: 0,0 / 21,5 / 34,0 / 41,6 / 47,0 / 77,6 s) + deriva lenta de zoom SIEMPRE activa entre ellos (≈ 0,3–1 %/s; 15 s seguidos de zoom-out en 47–62 s).
- Gráficos: 1 bloque split de 17 s (20 % del video) con 5 cambios (uno cada ≈ 3,4 s); 10 textos de fondo (uno cada ≈ 6,5 s fuera del split), duración 0,2–4,1 s (media ≈ 2,1 s; CTA 8,3 s).
- Respiro: 63,9–74,5 s sin ningún gráfico.

## Subtítulo (medido en fotogramas 1080×1920) — observado
- Fuente: sans grotesca fina tipo SF Pro / Inter Regular (familia exacta desconocida), tracking apretado, minúsculas; mayúscula solo al inicio de frase y signos «¿?».
- Color blanco #FFFFFF con halo/sombra oscura muy suave; sin caja, sin contorno.
- Tamaño: banda de texto 37–43 px de alto → cuerpo ≈ 44–48 px = 2,3–2,5 % del alto (≈ 4,2 % del ancho). Ancho del bloque: 6 % («se») a 34 % («automático»).
- Posición: centrado en x = 50 %; y ≈ 59,5 % del alto a pantalla completa; 41 % en el split (justo bajo el borde del negro, sobre su cabeza). Siempre encima del micro/pecho.
- Palabras por bloque: 1–3 (mayoría 1–2). Cambia por corte seco cada ≈ 0,4–0,7 s (sigue la voz); se «congela» cuando el texto de fondo dice la palabra.
- Resaltado: NO hay color de palabra clave. El énfasis es subtítulo en BOLD ≈ 1,35× (1 sola vez: «construye», 75,2 s) o pasar la palabra al texto de fondo.

## Texto de fondo (el recurso estrella) — observado
- Sans bold minúsculas (tipo SF Pro Display / Inter Bold), color melocotón-dorado ≈ #EBB072 (muestra 235,176,114) con degradado de opacidad izquierda→derecha: la 2ª mitad de la palabra casi se funde con la pared.
- Va DETRÁS de la cabeza (rotoscopia: el pelo lo tapa). Altura 100–135 px (≈ 6–7 % del alto), centro en y ≈ 15–19 %, ancho 30–95 %.
- Entra: fundido + desenfoque→nítido + barrido izq→der (0,25–0,35 s). Sale: desenfoque + fundido (≈ 0,15 s). Aparece 0,1–0,3 s DESPUÉS de empezar la palabra dicha.

## Split y tarjeta — observado (7,2 s)
- Negro puro #000000 de y = 0 a 36,5 % del alto; borde inferior difuminado ≈ 60 px; video abajo (63,5 %) a ancho completo, él reescalado a ≈ 70 %.
- Tarjeta-foto: 351×527 px (32,5 % × 27,4 %, proporción 2:3), radio ≈ 27 px (≈ 8 % de su ancho), borde blanco 4–6 px, foto con blur fuerte; centro x 51 %, y 18 %.
- Iconos de contorno blanco con glow: trazo ≈ 11 px (1 % del ancho); flechas de 6 px (0,55 %), #DCDCDC.
- Entra con zoom-blur de 2 fr (4,32–4,40 s); sale con blur + fundido cruzado de ≈ 5 fr (21,5 s).

## Color y fondos — observado/derivado
- Grado cálido y oscuro: pared ≈ #4F3A24–#56402A, luz ámbar lateral izquierda, mesa gris-beige ≈ #68564B, camiseta blanca como punto más claro; contraste medio, viñeta natural. Grano: desconocido (no apreciable con esta compresión).
- Sin texturas de papel/halftone. Una sola toma: 0 cortes de cámara detectados; todos los «cambios de plano» son escala animada en postproducción.
- **Sonido** (derivado de energía de audio; no escuchado): Sin música continua apreciable (stem sin voz ≈ −38 dB). Picos: 0,24 s (apertura), 0,84 s (clic con el logo) y 4,5 s (whoosh/impacto, el más fuerte, entrada al split). Resto: desconocido.

## Técnicas destacables
1. Apertura con zoom-out desenfocado de 0,28 s (0,00 s) en vez de título.
2. Logo de marca como texto de fondo, sincronizado con la palabra (0,84 s).
3. Diagrama en cinta transportadora: cada nodo sale a la izquierda y entra el siguiente (8,6 / 12,0 / 16,7 / 20,1 s).
4. Flechas que se dibujan (6,2 s) y «SERVICIOS» letra a letra (20,2 s).
5. Punch-in tapado con 3 fr de blur (34,0 s).
6. Sustitución de palabra de fondo en el sitio: «funnel»→«de ventas» (36,8 s), «atención»→«y autoridad» (43,5 s).
7. Dos recursos para dos opuestos: «construye» bold (75,2 s) / «comprar» fondo (76,9 s).
8. Palabra del CTA entre comillas fija 8 s hasta el último fotograma (78,7 s→).

## Reglas copiables
- Subtítulo diminuto (≈ 2,4 % del alto), blanco, 1–2 palabras, centrado sobre el pecho; nunca color.
- 1 texto de fondo cada 6–7 s, solo en la palabra que resume la frase; 1–2 s en pantalla; detrás de la cabeza.
- Nunca cortar: saltar de escala con animación de 0,3 s o con blur, y dejar siempre una deriva lenta.
- Punch-in en «Luego / Ahora / Y aquí / Comenta» (inicio de bloque), no en palabras sueltas.
- Un único bloque gráfico grande por video, al empezar la explicación, con iconos de línea blanca sobre negro.
- Si el fondo dice la palabra, el subtítulo no la repite.
- Antes del cierre, 8–10 s sin nada para que el CTA destaque.
