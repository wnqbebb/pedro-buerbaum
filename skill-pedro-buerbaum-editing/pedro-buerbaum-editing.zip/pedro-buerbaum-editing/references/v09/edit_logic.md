# v09 — lógica de edición: 10 reglas copiables

_Evidencia: tiempos de palabra = observado (evidence.json); aparición en pantalla = observado en tiras a 12,5 fps (±0,08 s); escalas de cámara = derivado del seguimiento de la base del micro (±3 %); «por qué» = inferido; sonido = derivado, no escuchado._

1. **Abrir con zoom, no con título.** Fotograma 0 a ≈ 125 % y desenfocado → encuadre base en 0,28 s (0,00–0,28 s). Golpe sonoro a 0,24 s.
2. **La marca que se nombra aparece detrás de la cabeza.** «only» (0,70 s) → logo OnlyFans a 0,84 s (+0,14 s) con fundido+blur 0,3 s y clic. Se queda 3,5 s.
3. **Al empezar la explicación, partir la pantalla.** «Ellas» (4,56 s): zoom-blur de 2 fr (4,32–4,40 s) → negro #000 arriba 36,5 % / él abajo al 70 %. Dura 17 s (hasta 21,48 s).
4. **Un nodo del diagrama por concepto, en el fotograma de la palabra.** «embudo» 8,64 s → embudo 8,70 s; «Crean» 11,82 → tarjeta 12,0; «Y luego… plataforma» 16,58 → logo en línea 16,70; «considere» 20,14 → «SERVICIOS» 20,15. Offset típico +0,05 a +0,2 s.
5. **Cinta transportadora.** El nodo saliente se desliza a la izquierda y se funde (0,2 s), 1–2 fr de negro, entra el siguiente (0,25 s). Las flechas de 6 px se dibujan en 0,35 s (6,2 / 15,0 / 18,4 s).
6. **Salir del gráfico con blur hacia un plano MÁS cerrado.** 21,48 s: blur + fundido de ≈ 5 fr; él entra borroso y enfoca en 0,2 s a ≈ 112 %.
7. **Texto de fondo = la palabra que resume la frase, 0,2–0,3 s después de empezar a decirla.** «sí» 27,70→27,95; «valor» 31,98→32,2; «increíble» 52,38→52,7; «comprar» 76,70→76,88. Duración 1–2 s; sale con blur 0,15 s.
8. **Sustituir en el sitio cuando hay dos palabras seguidas.** «funnel»→«de ventas» (36,6→36,8 s); «atención»→«y autoridad» (42,9→43,5 s). Misma posición, sin animación de salida de la primera.
9. **Golpes de escala en los conectores de bloque, nunca cortes.** «Luego,» 34,0 s (+10 %, tapado con 3 fr de blur) · «Ahora» 41,6 s (−15 % en 0,3 s) · «Y aquí está la clave» 47,0 s (+14 % en 0,3 s) · «Comenta» 77,6 s (+8 %). Entre golpes, deriva lenta continua (47,4–62 s: 15 s de zoom-out).
10. **CTA = palabra entre comillas fija detrás hasta el final.** «autoridad» 78,48 s → «“Autoridad”» 78,7 s, ancho 95 %, 8,3 s en pantalla; el video acaba sin tarjeta.

**Extras medidos**
- Subtítulo: 1–3 palabras, ≈ 46 px, y = 59,5 % (41 % en el split); cambia por corte.
- Único bold del subtítulo: «construye» (75,2 s), contrapuesto a «comprar» en el fondo (76,9 s).
- Silencio gráfico de 10 s (63,9–74,5 s) antes del remate.
- Densidad de eventos por 10 s: 6, 5, 4, 5, 8, 1, 1, 7, 0.
