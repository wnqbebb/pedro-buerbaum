# v10 — «Paso 1, creas contenido…» (109,0 s, 1080×1920, 25 fps)
**Formato propuesto** (labels.json = "?"): `busto_parlante_mesa_micro (lista de 3 pasos)` — 100 % A-roll a pantalla completa; ni split, ni tarjeta, ni b-roll. Todo el grafismo vive detrás de su cabeza.

## Estructura del guion
1. **Hook 0–9,4 s** arranca en «Paso 1» (sin introducción) + qué NO hacer (buscar audiencia).
2. **Paso 1 (9,4–20,7 s)** mezcla exposición/autoridad. **Paso 2 (20,7–37,2 s)** oferta (estructura, pricing). **Paso 3 (37,2–46,6 s)** ecosistema (sistemas, metodología).
3. **Resultado 46,6–60,2 s** crecer exponencialmente + oportunidades.
4. **Tesis 60,2–74,3 s** marca personal «de verdad» vs «“marca personal”».
5. **Consecuencias 74,3–104 s** referencia, poco a poco, complejidad, empresa.
6. **Cierre 104–109 s** «quieres monetizarla» (sin CTA).

## Ritmo (derivado)
- 38 escenas → 2,9 s/escena.
- Cambio de encuadre: 9 golpes de zoom rápidos (0,2–0,4 s) → uno cada ≈ 12 s (5,5 / 8,9 / 12,6 / 23,0 / 51,7 / 60,6 / 72,0 / 78,2 / 107,9 s), más derivas lentas; tramo totalmente fijo de 15 s (23,9–38,5 s).
- Gráficos: 20 textos/gráficos de fondo → uno cada ≈ 5,4 s. Duración: «Paso N» 4–7 s; palabras de énfasis 1,3–2,4 s; palabras en serie 0,5–0,8 s; eje 4,2 s; anillos 3,5 s. Media ≈ 2,3 s.
- 6 subtítulos en negrita (audiencia, objetivo, ecosistema, de negocio, impresionante).

## Subtítulo (medido en fotogramas 1080×1920) — observado
- Fuente: sans grotesca fina tipo SF Pro / Inter Regular (familia exacta desconocida), tracking apretado, minúsculas; mayúscula solo al inicio de frase y signos «¿?».
- Color blanco #FFFFFF con halo/sombra oscura muy suave; sin caja, sin contorno.
- Tamaño: banda de texto 37–43 px de alto → cuerpo ≈ 44–48 px = 2,3–2,5 % del alto (≈ 4,2 % del ancho). Ancho del bloque: 6 % («se») a 34 % («automático»).
- Posición: centrado en x = 50 %; y ≈ 55,6 % del alto. Siempre encima del micro/pecho.
- Palabras por bloque: 1–3 (mayoría 1–2). Cambia por corte seco cada ≈ 0,4–0,7 s (sigue la voz); se «congela» cuando el texto de fondo dice la palabra.
- Resaltado: NO hay color de palabra clave. El énfasis es subtítulo en BOLD ≈ 1,35× (≈ 60 px), a veces sostenido 1,5 s («impresionante»), o texto de fondo.

## Texto de fondo (el recurso estrella) — observado
- Sans bold minúsculas (tipo SF Pro Display / Inter Bold), color melocotón-dorado ≈ #EBB072 (muestra 235,176,114) con degradado de opacidad izquierda→derecha: la 2ª mitad de la palabra casi se funde con la pared.
- Va DETRÁS de la cabeza (rotoscopia: el pelo lo tapa). Altura 100–135 px (≈ 6–7 % del alto), centro en y ≈ 15–19 %, ancho 30–95 %.
- Entra: fundido + desenfoque→nítido + barrido izq→der (0,25–0,35 s). Sale: desenfoque + fundido (≈ 0,15 s). Aparece 0,1–0,3 s DESPUÉS de empezar la palabra dicha.
- Tamaño adaptable: «exponencialmente» baja a ≈ 4,5 % del alto para caber de borde a borde.

## Gráficos propios — observado
- **Eje AUTORIDAD / EXPOSICIÓN (12,2–16,4 s)**: línea dorada de 3–4 px de x 4 % a 96 %, y ≈ 16,5 %, write-on 0,5 s; rótulos en sans MAYÚSCULAS de peso medio, tracking muy abierto, ≈ 2,3 % del alto; inclinación ≈ 1–2° siguiendo la pared.
- **Anillos «el centro» (33,4–36,9 s)**: 2 círculos concéntricos de 2–3 px, dorado semitransparente, radios ≈ 16 % y 22 % del ancho, centrados en su cabeza, detrás de él.
- **Comillas tipográficas** en «“Marca personal”» (72,2 s) coincidiendo con su gesto de comillas.
- No hay tarjeta ni fondo negro en este video.

## Color y fondos — observado/derivado
- Grado cálido y oscuro: pared ≈ #4F3A24–#56402A, luz ámbar lateral izquierda, mesa gris-beige ≈ #68564B, camiseta blanca como punto más claro; contraste medio, viñeta natural. Grano: desconocido (no apreciable con esta compresión).
- Sin texturas de papel/halftone. Una sola toma: 0 cortes de cámara detectados; todos los «cambios de plano» son escala animada en postproducción.
- **Sonido** (derivado; no escuchado): Suelo entre palabras alto (−22,6 dB; en los otros tres −33/−35 dB) → probable música/ambiente continuo. Tipo desconocido. SFX en golpes de zoom: desconocido (sin stem separado).

## Técnicas destacables
1. Rótulo de capítulo «Paso 1/2/3» siempre en el mismo sitio (0,1 / 20,8 / 37,4 s).
2. Golpe de zoom + subtítulo bold en la misma palabra («audiencia», 5,5 s).
3. Línea que se dibuja y dos rótulos como mini-diagrama integrado en la pared (12,2 s).
4. Series de 4 palabras que siguen la voz (28,6 y 42,4 s).
5. Halo de anillos para «el centro» (33,4 s).
6. Comillas tipográficas = gesto (72,2 s).
7. Texto que se construye palabra a palabra: «poco a poco» (86,7 s) · Cierre: punch-in + palabra final + dedo en la mesa (107,9 s).

## Reglas copiables
- En listas, rotular cada paso detrás de la cabeza y dejarlo 4–7 s.
- Golpe de zoom (≈ +6–10 % en 0,3 s, ease-out) solo en la palabra de mayor carga de cada bloque; después dejar que la cámara se aleje sola durante 5–10 s.
- Alternar tres niveles de énfasis: subtítulo normal → subtítulo bold → texto de fondo. Nunca dos a la vez sobre la misma palabra.
- Requisitos/enumeraciones: palabras de fondo sucesivas en el mismo punto, 0,5–0,8 s cada una.
- Un gráfico de línea fina (eje, anillo) por cada idea espacial; mismo dorado que el texto.
- Se puede aguantar 15 s de plano fijo si hay 3 elementos de fondo en ese tramo.
- Terminar en una palabra de fondo, sin tarjeta final.
