# v10 — lógica de edición: 10 reglas copiables

_Evidencia: tiempos de palabra = observado (evidence.json); aparición en pantalla = observado en tiras a 12,5 fps (±0,08 s); escalas de cámara = derivado del seguimiento de la base del micro (±3 %); «por qué» = inferido; sonido = derivado, no escuchado._

1. **Empezar en «Paso 1» y rotularlo.** «Paso» 0,00 s → «Paso» detrás a 0,08 s, el «1» ≈ 0,3 s después; apertura con zoom-out de 0,28 s. El rótulo dura 6 s (hasta 6,08 s).
2. **Mismo rótulo, mismo sitio, para cada capítulo.** «Paso 2» 20,68→20,84 s (6,8 s) · «Paso 3» 37,28→37,36 s (4,2 s). y ≈ 10–17 %, detrás de la cabeza.
3. **Golpe de zoom + negrita en la palabra más cargada.** «audiencia» 5,50 s: push-in +9 % en 0,32 s (5,48–5,80) y subtítulo bold ≈ 1,35×; a la vez «Paso 1» se va con blur (6,0 s).
4. **Después de cada golpe, dejar que la cámara se aleje sola.** 9,36–12,64 s (−16 % en 3,3 s); 44,4–51,5 s; 54,3–59,8 s; 81,2–92,3 s (11 s).
5. **Dos conceptos enfrentados = una línea y dos rótulos.** «exposición» 11,60 s → línea dorada se dibuja 12,15–12,7 s + «EXPOSICIÓN» (12,4) y «AUTORIDAD» (12,8); el subtítulo se congela en «entre» 3 s. Sale a 16,4 s.
6. **Enumeraciones: una palabra de fondo por término, sustituida en el sitio.** estructura 28,6 → correcta 29,1 → pricing 29,9 → adecuado 30,4 (offset +0,05–0,1 s); repetir el patrón más tarde: sistemas 42,44 → adecuados 42,7 → metodología 43,9 → correcta 44,6.
7. **Metáfora espacial = gráfico de línea alrededor de la cabeza.** «centro» 33,20 s → 2 anillos concéntricos a 33,4 s (3,5 s).
8. **Alternar el canal del énfasis.** Fondo («exponencialmente» 52,4 s) → subtítulo bold sostenido 1,5 s («impresionante» 56,3 s) → fondo («oportunidades» 58,4 s). Nunca los dos sobre la misma palabra.
9. **Sincronizar grafismo con gesto.** Comillas con los dedos + «“Marca personal”» a 72,24 s + zoom-out rápido (−6 % en 0,4 s). «poco a poco» se construye palabra a palabra (86,7 s) mientras desliza la mano.
10. **Cerrar con golpe + palabra + gesto.** «monetizarla» 107,92 s: push-in +10 % en 0,28 s (107,88) y palabra detrás a 108,2 s; fin a 108,96 s sin CTA.

**Extras medidos**
- 9 golpes de zoom (uno cada ≈ 12 s); 20 elementos de fondo (uno cada ≈ 5,4 s).
- Plano completamente fijo 23,9–38,5 s (15 s) sostenido por «Paso 2», serie de 4 palabras y anillos.
- Subtítulo 1–3 palabras, ≈ 46 px, y = 55,6 %.
- Suelo sonoro alto entre palabras (−22,6 dB): probable música/ambiente continuo (inferido).
- Densidad de eventos por 10 s: 7, 4, 8, 4, 7, 6, 4, 5, 2, 2, 3.
