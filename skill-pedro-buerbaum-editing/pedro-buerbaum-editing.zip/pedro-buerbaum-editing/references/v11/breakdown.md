# v11 — «Esto de aquí ha cambiado por completo» (94,4 s, 1080×1920, 25 fps)
**Formato propuesto** (labels.json = "?"): `busto_parlante_mesa_micro (opinión/tesis)` — A-roll a pantalla completa con texto detrás, 2 fotos insertadas detrás del sujeto y logo de su programa. Sin split ni fondo negro.

## Estructura del guion
1. **Hook 0–7,9 s** «ha cambiado por completo» + «los seguidores importan menos».
2. **Antes 7,9–20,4 s** viralizar y esperar que alguien encaje.
3. **Ahora 20,4–45 s** algoritmos precisos: nicho, 2–4 mil personas exactas, cada publicación por separado.
4. **Ejemplo personal 45–59 s** reel de pesca/golf.
5. **Giro 59–79,5 s** si no vendes, el fallo es contenido/oferta/comunicación; «el gran villano».
6. **Oferta + CTA 79,5–94,3 s** Creator Founder → «escríbeme un DM».

## Ritmo (derivado)
- 29 escenas → 3,3 s/escena.
- Cambio de encuadre: 5 golpes de zoom, más lentos que en v09/v10 (0,5–1,2 s) → uno cada ≈ 19 s (8,8 / 13,5 / 42,3 / 51,4 / 64,1 s) + derivas lentas; tramo fijo de 15 s (23,6–38,5 s).
- Gráficos: 13 elementos de fondo → uno cada ≈ 7 s; palabras 1–3,5 s (media ≈ 2,2 s), fotos 2,7 s, logo 9 s.
- CTA final de 4,5 s sin ningún gráfico.

## Subtítulo (medido en fotogramas 1080×1920) — observado
- Fuente: sans grotesca fina tipo SF Pro / Inter Regular (familia exacta desconocida), tracking apretado, minúsculas; mayúscula solo al inicio de frase y signos «¿?».
- Color blanco #FFFFFF con halo/sombra oscura muy suave; sin caja, sin contorno.
- Tamaño: banda de texto 37–43 px de alto → cuerpo ≈ 44–48 px = 2,3–2,5 % del alto (≈ 4,2 % del ancho). Ancho del bloque: 6 % («se») a 34 % («automático»).
- Posición: centrado en x = 50 %; y ≈ 54 % del alto. Siempre encima del micro/pecho.
- Palabras por bloque: 1–3; variante ACUMULATIVA en el gancho («Las redes» + «sociales»: la palabra nueva entra ≈ 60 % de tamaño, gris, 20 px más abajo y sube en 0,2 s). Cambia por corte seco cada ≈ 0,4–0,7 s (sigue la voz); se «congela» cuando el texto de fondo dice la palabra.
- Resaltado: NO hay color de palabra clave. El énfasis es subtítulo en BOLD ≈ 1,35× para cifras y ejemplos («2 mil / 3 mil / 4 mil», «de pesca», «de golf») o texto de fondo.

## Texto de fondo (el recurso estrella) — observado
- Sans bold minúsculas (tipo SF Pro Display / Inter Bold), color melocotón-dorado ≈ #EBB072 (muestra 235,176,114) con degradado de opacidad izquierda→derecha: la 2ª mitad de la palabra casi se funde con la pared.
- Va DETRÁS de la cabeza (rotoscopia: el pelo lo tapa). Altura 100–135 px (≈ 6–7 % del alto), centro en y ≈ 15–19 %, ancho 30–95 %.
- Entra: fundido + desenfoque→nítido + barrido izq→der (0,25–0,35 s). Sale: desenfoque + fundido (≈ 0,15 s). Aparece 0,1–0,3 s DESPUÉS de empezar la palabra dicha.

## Gráficos propios — observado
- **Tachado (5,5–7,6 s)**: «seguidores» + línea clara ≈ 5 px (≈ #F8E0B0) que lo cruza a media altura, sobresaliendo ≈ 3 % por lado; write-on 0,25 s.
- **Fotos-tarjeta (48,7–51,4 s)**: 2 fotos verticales sin borde, radio ≈ 25–30 px, cada una ≈ 30 % del ancho × 28 % del alto, DETRÁS de él (x 13–43 % y 55–85 %, y 6–34 %), con leve giro; entran con fundido+blur 0,3 s, salen con blur 0,15 s. El video NO se encoge.
- **Logo «creatorfounder» (80,7–89,6 s)**: «creator» sans bold + «founder» serif itálica fina (tipo Playfair/Canela Italic; exacta desconocida), melocotón-dorado, de borde a borde (≈ 98 % del ancho), ≈ 5,5 % del alto.

## Color y fondos — observado/derivado
- Grado cálido y oscuro: pared ≈ #4F3A24–#56402A, luz ámbar lateral izquierda, mesa gris-beige ≈ #68564B, camiseta blanca como punto más claro; contraste medio, viñeta natural. Grano: desconocido (no apreciable con esta compresión).
- Sin texturas de papel/halftone. Una sola toma: 0 cortes de cámara detectados; todos los «cambios de plano» son escala animada en postproducción.
- **Sonido** (derivado; no escuchado): Silencio real entre frases (mínimo −77 dB; pausas −35,5 dB) → sin música continua apreciable. SFX: desconocido (sin stem separado).

## Técnicas destacables
1. Dos palabras de fondo en el primer segundo (0,56 y 1,0 s) + manos arriba.
2. Subtítulo acumulativo (1,9 y 3,9 s).
3. Palabra tachada (5,75 s).
4. Push-in de 0,6 s sobre la sonrisa irónica en «viralizar» (8,8 s).
5. Cifras en bold «2 mil → 3 mil → 4 mil» con «nicho» detrás (31,9 s).
6. Fotos detrás de la cabeza para el ejemplo personal (48,7 s).
7. Subtítulo congelado «está en tu» + 3 palabras de fondo (64,4–69 s).
8. Logo como texto de fondo 9 s (80,7 s).

## Reglas copiables
- Tachar la palabra-creencia que el video viene a desmontar (una vez por video).
- Ejemplo personal → fotos reales en tarjetas redondeadas detrás del sujeto, 2–3 s, nunca a pantalla completa.
- Listas de 3: subtítulo-plantilla fijo + palabra de fondo cambiante.
- Cifras: abreviadas («2 mil») y en bold en el subtítulo.
- Golpes de zoom largos (0,5–1,2 s) cuando la frase es explicativa; reservar los de 0,3 s para remates.
- El logo propio entra como un texto de fondo más (mismo color), no como banner.
- CTA dicho a cámara, sin gráfico.
