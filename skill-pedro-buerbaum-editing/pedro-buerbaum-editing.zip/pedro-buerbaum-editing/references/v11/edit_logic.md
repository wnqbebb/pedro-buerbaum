# v11 — lógica de edición: 10 reglas copiables

_Evidencia: tiempos de palabra = observado (evidence.json); aparición en pantalla = observado en tiras a 12,5 fps (±0,08 s); escalas de cámara = derivado del seguimiento de la base del micro (±3 %); «por qué» = inferido; sonido = derivado, no escuchado._

1. **Dos palabras de fondo en el primer segundo.** «cambiado» 0,62 s → detrás a 0,56 s; «por completo» 0,96 → 1,0 s (hasta 2,5 s). Apertura con zoom-out de 0,28 s y manos arriba.
2. **Subtítulo acumulativo para la frase paradójica.** «Las redes» (1,9 s) + «sociales» que entra pequeña y gris 20 px más abajo y sube en 0,2 s; igual «como redes sociales» (3,9–4,6 s).
3. **Tachar la creencia.** «seguidores» 5,50 s → palabra detrás a 5,52 s; línea de tachado se dibuja a 5,75 s (0,25 s). 2,1 s en pantalla.
4. **Push-in sobre la expresión.** «el juego era viralizar»: push-in +12 % en 0,6 s (8,84–9,48 s) hasta su sonrisa irónica; «viralizar» detrás a 9,44 s.
5. **Golpes de zoom más largos en frases explicativas.** 13,52 s (+10 % en 0,5 s) · 42,28 s (+11 % en 1,2 s) · 51,44 s (+11 % en 0,5 s). Entre medias, zoom-out lento (16,3–22,6 s; 44,6–51 s; 57,9–63,8 s).
6. **Cifras abreviadas y en negrita en el subtítulo.** «2 mil» 31,9 s → «3 mil» 32,7 s → «4 mil» 33,1 s, con «nicho» detrás (30,7–34,2 s).
7. **Ejemplo personal = fotos detrás de él.** «salida» 48,74 s → foto de pesca (48,7 s, arriba-izquierda); «partida» 49,72 s → foto de golf (49,8 s, arriba-derecha); subtítulos bold «de pesca» / «de golf». Salen con blur a 51,4 s junto con un push-in.
8. **Subtítulo-plantilla + fondo cambiante.** Subtítulo congelado «está en tu» 63,4–68,6 s; detrás «contenido» 64,36 → «oferta» 65,6 → «comunicación» 66,92 s.
9. **Etiqueta irónica palabra a palabra.** «el» → «gran» → «villano» desde 72,24 s (≈ 0,15 s cada una), 1,8 s.
10. **La marca propia entra como texto de fondo.** «Creator» 80,20 s → logo «creatorfounder» (sans bold + serif itálica) a 80,68 s con zoom-out de 0,5 s; 9 s en pantalla; CTA final (89,76–94,3 s) sin gráfico.

**Extras medidos**
- 5 golpes de zoom (uno cada ≈ 19 s); 13 elementos de fondo (uno cada ≈ 7 s).
- Plano fijo 23,6–38,5 s (15 s).
- Subtítulo 1–3 palabras, ≈ 46 px, y = 54 %; encuadre base más abierto que v09/v10.
- Sin música continua apreciable (pausas a −35,5 dB; inferido).
- Densidad de eventos por 10 s: 10, 4, 1, 5, 7, 5, 4, 2, 2, 0.
