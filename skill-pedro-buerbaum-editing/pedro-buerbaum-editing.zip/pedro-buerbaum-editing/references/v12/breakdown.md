# v12 — «Transcribe las llamadas de tu equipo de ventas» (65,5 s, 1080×1920, 25 fps)
**Formato propuesto** (labels.json = "?"): `busto_parlante_mesa_micro + demo_gráfica_sobre_negro` — A-roll con un bloque tutorial de 12 s en el que él queda recortado sobre negro con cuadrícula y maquetas de interfaz arriba.

## Estructura del guion
1. **Hook de cualificación 0–9,3 s** «solo te sirve si tienes producto/servicio high ticket y equipo de ventas».
2. **Promesa 9,3–18 s** multiplicar ×10 con algo muy simple.
3. **Método 18–30,4 s** transcribir llamadas → IA → resumen → objeciones más comunes (bloque gráfico).
4. **Aplicación 30,4–57 s** la lista guía tu contenido orgánico; tocas el dolor y demuestras entendimiento.
5. **Bonus 57–63,4 s** guiones de anuncios.
6. **Cierre 63,4–65,1 s** «Esto es un game changer» (sin CTA).

## Ritmo (derivado)
- 20 escenas → 3,3 s/escena.
- Cambio de encuadre: muy poco. Primeros 18 s fijos; después 2 cambios de modo (18,2 y 30,2 s), 1 golpe de zoom (45,1 s, 0,7 s) y 1 push-in lento de 2,7 s (53,0 s) → un cambio cada ≈ 13 s de media.
- Gráficos: bloque sobre negro de 12 s (18 % del video) con 4 gráficos (terminal 3,9 s · iconos 2,1 s · panel 2,7 s · lista 2,7 s; uno cada ≈ 3 s). Textos de fondo: 5 (producto / o servicio / High Ticket / x 10 / game changer), 0,8–3,5 s.
- 30–63 s: 33 s sin texto de fondo.

## Subtítulo (medido en fotogramas 1080×1920) — observado
- Fuente: sans grotesca fina tipo SF Pro / Inter Regular (familia exacta desconocida), tracking apretado, minúsculas; mayúscula solo al inicio de frase y signos «¿?».
- Color blanco #FFFFFF con halo/sombra oscura muy suave; sin caja, sin contorno.
- Tamaño: banda de texto 37–43 px de alto → cuerpo ≈ 44–48 px = 2,3–2,5 % del alto (≈ 4,2 % del ancho). Ancho del bloque: 6 % («se») a 34 % («automático»).
- Posición: centrado en x = 50 %; y ≈ 50,7 % del alto a pantalla completa; 48 % en el bloque sobre negro. Siempre encima del micro/pecho.
- Palabras por bloque: 1–5 (más largo que en los otros: «tienes que hacer algo», «y un equipo de ventas»), a menudo acumulativo. Cambia por corte seco cada ≈ 0,4–0,7 s (sigue la voz); se «congela» cuando el texto de fondo dice la palabra.
- Resaltado: NO hay color de palabra clave. El énfasis es SUBTÍTULO DE 2 LÍNEAS: frase fina arriba + palabra clave debajo en BOLD ≈ 1,4× (≈ 58–62 px), interlineado tan apretado que se tocan (utilidad, funcionamiento, completo, muy simple→accesible, potenciales, solucionar).

## Texto de fondo (el recurso estrella) — observado
- Sans bold minúsculas (tipo SF Pro Display / Inter Bold), color melocotón-dorado ≈ #EBB072 (muestra 235,176,114) con degradado de opacidad izquierda→derecha: la 2ª mitad de la palabra casi se funde con la pared.
- Va DETRÁS de la cabeza (rotoscopia: el pelo lo tapa). Altura 100–135 px (≈ 6–7 % del alto), centro en y ≈ 15–19 %, ancho 30–95 %.
- Entra: fundido + desenfoque→nítido + barrido izq→der (0,25–0,35 s). Sale: desenfoque + fundido (≈ 0,15 s). Aparece 0,1–0,3 s DESPUÉS de empezar la palabra dicha.
- «x 10» es el mayor (≈ 8 % del alto).

## Bloque sobre negro (18,2–30,2 s) — observado
- Fondo #000000 con cuadrícula gris fina (≈ 2 px) deformada/ondulada, celdas ≈ 12 % del ancho. Él recortado (sin su fondo), ≈ 88 % de escala, cabeza en y ≈ 50–62 %.
- **Terminal**: rectángulo ≈ #0E0E10, radio ≈ 15 px, x 16–84 %, y 10–50 %; título «Transcripción», 3 puntos de semáforo, texto monoespaciado tecleado, cursor amarillo.
- **Iconos IA**: 5 cuadrados redondeados (radio ≈ 22 % del lado), lado ≈ 11–13 % del ancho, a color; pop de 0,15 s cada 0,2 s.
- **Panel**: tarjeta ≈ #1C2230, radio ≈ 30 px, x 8–92 %, y 13–40 %, giro 3D leve; «Analizando transcripción… 52 llamadas de ventas», barra de progreso amarilla.
- **Lista**: «Objeciones **más comunes:**» (resaltado: texto negro sobre caja blanca) + 3 cajas de borde blanco 3 px, 54 % × 7 %: «El precio», «Falta de tiempo», «Comparar opciones».
- Entra con 2–3 fr de blur (18,24 s); sale con blur y fundido de ≈ 7 fr (30,16 s).

## Color y fondos — observado/derivado
- Grado cálido y oscuro: pared ≈ #4F3A24–#56402A, luz ámbar lateral izquierda, mesa gris-beige ≈ #68564B, camiseta blanca como punto más claro; contraste medio, viñeta natural. Grano: desconocido (no apreciable con esta compresión).
- Sin texturas de papel/halftone. Una sola toma: 0 cortes de cámara detectados; todos los «cambios de plano» son escala animada en postproducción.
- **Sonido** (derivado; no escuchado): Clic + «pop» en la apertura (0,20–0,27 s; pico máximo del stem sin voz). El stem sube ≈ 5 dB entre 22 y 32 s → se intuyen sonidos de interfaz/tecleo o un lecho bajo el bloque gráfico (inferido). Sin música continua evidente.

## Técnicas destacables
1. Hook sin título: zoom-out borroso de 0,16 s + pop.
2. Serie de 3 requisitos detrás mientras cuenta con los dedos (3,6–6,8 s).
3. Subtítulo de 2 líneas con palabra bold intercambiable (16,0→16,7 s).
4. «x 10» en dos tiempos (10,9 / 11,15 s).
5. Cambio a «modo tutorial»: sujeto recortado sobre negro con cuadrícula (18,2 s).
6. Maquetas de interfaz que cuentan el proceso en 4 pasos (18,4 / 22,3 / 24,6 / 27,4 s).
7. Push-in lento de 2,7 s como clímax (53,0 s) · Cierre «Esto es un» (subtítulo) + «game changer» (fondo) (64,0 s).

## Reglas copiables
- Si el video enseña un proceso con herramientas, dedicar ≈ 18 % a un bloque sobre negro con maquetas de UI, 1 gráfico cada 3 s, con él recortado abajo.
- Usar los iconos reales de las apps (a color) cuando se nombran.
- Dar el resultado como lista de 3 cajas (fotograma «guardable»).
- Fuera del bloque gráfico, casi nada: subtítulo de 2 líneas para el énfasis y la cámara quieta.
- Cifra-promesa («x 10») como texto de fondo más grande del video.
- Un solo push-in lento en el clímax; terminar con frase-sello detrás.
