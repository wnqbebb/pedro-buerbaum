# v12 — lógica de edición: 10 reglas copiables

_Evidencia: tiempos de palabra = observado (evidence.json); aparición en pantalla = observado en tiras a 12,5 fps (±0,08 s); escalas de cámara = derivado del seguimiento de la base del micro (±3 %); «por qué» = inferido; sonido = derivado, no escuchado._

1. **Hook sin texto grande: golpe de apertura.** Zoom-out borroso de 0,16 s (0,00 s) + clic/pop a 0,20–0,27 s. Cámara fija los siguientes 18 s.
2. **Subtítulo de 2 líneas para el énfasis.** Frase fina arriba + palabra clave bold ≈ 1,4× debajo: «te va a ser de / utilidad» (2,3 s), «en / funcionamiento» (8,3 s), «ecosistema / completo» (14,2 s), «clientes / potenciales» (39,5 s), «quieres / solucionar» (55,2 s).
3. **Palabra bold intercambiable.** «tienes que hacer algo» fijo + «muy simple» (16,0 s) → «accesible» (16,7 s).
4. **Requisitos del oyente = serie de fondo al ritmo de los dedos.** «producto» 3,62→3,64 s · «o servicio» 4,44 s · «High Ticket» 5,5 s; el subtítulo se queda en «tienes un» 3,5 s.
5. **La cifra-promesa es el texto más grande.** «por 10» 10,70 s → «x» a 10,9 s y «10» a 11,15 s (≈ 8 % del alto), 3,5 s en pantalla.
6. **Para el «cómo», cambiar a modo tutorial.** «Vas» 18,08 s → 2–3 fr de blur (18,24) → él recortado sobre negro #000 con cuadrícula deformada, gráfico arriba. 12 s (hasta 30,16 s).
7. **Un gráfico por paso del proceso, cada ≈ 3 s.** terminal que teclea la transcripción (18,4 s) → 5 iconos de IA en pop cada 0,2 s («cualquier» 22,48 → 22,3 s) → panel «Analizando… 52 llamadas» con barra de progreso («vas a pedir» 24,56 → 24,6 s) → lista de 3 cajas («cuáles» 27,62 → 27,45 s).
8. **Volver del gráfico con blur y frase-resumen.** 30,16 s: blur + fundido de ≈ 7 fr → A-roll a ≈ 108 %; «Necesitas tener una lista de objeciones» (30,42 s).
9. **Segunda mitad sobria y un push-in lento como clímax.** 33 s sin texto de fondo; golpe +7 % en 0,7 s en «dolor» (45,1 s); push-in +14 % en 2,7 s (53,0–55,7 s) que termina en «solucionar».
10. **Cierre: subtítulo plantea, fondo remata.** Subtítulo «Esto es un» (63,4 s) + «game» (64,0 s) → «changer» (64,6 s) detrás; fin a 65,4 s, sin CTA.

**Extras medidos**
- Subtítulos más largos que en el resto (hasta 5 palabras, acumulativos: «y un equipo de ventas», 6,9–8,0 s), ≈ 40–46 px, y = 50,7 % (48 % sobre negro).
- Lista: «más comunes:» en negro sobre caja blanca; cajas de borde 3 px, 54 % × 7 %.
- El stem sin voz sube ≈ 5 dB durante 22–32 s: se intuyen sonidos de interfaz (inferido).
- Densidad de eventos por 10 s: 7, 8, 3, 3, 5, 4, 2.
