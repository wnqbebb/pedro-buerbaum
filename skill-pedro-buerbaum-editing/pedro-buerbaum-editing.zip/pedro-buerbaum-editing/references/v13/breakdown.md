# v13 — desglose (Pedro Buerbaum) · «Nada en tu vida está separado: bucles»

Etiquetas de evidencia: **[O]** observado en fotogramas · **[D]** derivado (medido/calculado) · **[I]** inferido · **[?]** desconocido.

## Formato
- **FORMATO DISTINTO: horizontal 4:3, 1440×1080, 25 fps, 94,4 s** [O]. Un solo plano, **0 cortes** [D].
- Formato propuesto (labels.json dice "?"): **«busto en tarjeta + titulares serif flotantes»** (monólogo reflexivo, sin pizarra ni gráfico completo) [I].
- Todo el video va dentro de una **tarjeta redondeada fija**: 1270×952 px = 88,2 % del ancho × 88,1 % del alto, márgenes 85 px (lados) y 64 px (arriba/abajo), radio ≈85–90 px (≈7 % del ancho de tarjeta), fondo negro puro `#000000` [D].

## Estructura del guion
hook absoluto (0–5,6 s: «No hay absolutamente nada en tu vida… Nada.») → cadena causa-efecto negocio (5,6–43 s) → «todo sigue girando» (43 s) → cadena vida personal (44–60 s, clímax «vale la pena») → nombre de la tesis «bucle positivo» y apalancamiento (60–70 s) → giro «la mala noticia… al revés» (70–78 s) → tesis visual «son todo bucles… mejor o peor» (79–87 s) → cierre «desde este preciso momento» (92–94 s). **Sin CTA ni tarjeta final** [O].

## Ritmo
- 32 escenas en 94,4 s → **2,95 s/escena** [D]. 16 con rótulo/gráfico, 13 solo subtítulo, 2 hook, 1 cierre.
- **Cambios de encuadre: 1 en todo el video** (push-in suave +4,5 % entre 4,2 y 5,2 s) más el zoom-out de entrada (124→102 % en 0,16 s) [D]. Después solo una deriva de +1,7 % en 89 s.
- **Rótulo o gráfico cada ≈5,2 s de media** (18 bloques), en rachas: 6 en los primeros 10 s; casi nada de 15 a 40 s [D].
- Duración en pantalla: rótulo serif 0,9–1,7 s (media ≈1,3 s); titular inicial 3 s; aros 1,5 s; ∞ ≈7,5 s [D].

## Subtítulos (medidos)
- Sans neo-grotesca **regular**, blanco `#FFFFFF`, sin caja ni contorno [O]; tipo Helvetica Now/Inter [I].
- Tamaño: altura de mayúscula ≈32 px = **3,0 % del alto** (cuerpo ≈44 px ≈4 %) [D]. Posición: centrado, a **≈54,5 % del alto**, sobre el pecho/micro [D].
- **1–5 palabras por bloque (media ≈2,9)**; palabra clave en **bold** del mismo tamaño y color (≈1 de cada 2 bloques) [O].
- Animación: palabra a palabra; cada palabra entra ≈12–15 px más abajo, gris y algo desenfocada, y sube a blanco en 0,16–0,20 s; el bloque sale por fundido ≈0,15 s [O].

## Rótulos serif y gráficos
- Serif display de alto contraste, tracking apretado, minúsculas, blanco; mezcla romana ultralight + itálica [O] (tipo PP Editorial New / Ogg [I]).
- Tres tamaños: pequeño en 2 líneas (x ≈40 px), medio a los lados de la cara (x ≈60 px), gigante (x ≈75–85 px) [D].
- Posición habitual: **una palabra a la izquierda y otra a la derecha de la cara**, a 25–40 % del alto; nunca tapan la cara [O].
- Gráficos: solo **línea dorada fina** (≈3–5 px, `#F5DFA0→#C99A4A`, glow suave): 4 aros encadenados y símbolo ∞ con destello [O].
- Entrada: fundido + desenfoque→nítido 0,2–0,28 s, palabra a palabra; salida: fundido ≈0,15 s [O].

## Paleta, grado y texturas
- Cálido ámbar y oscuro: pared `#AE8B54`, sombras `#26160C`/`#362514`, camiseta blanca, micro negro, fondo `#000` [O]. Contraste suave, fondo desenfocado, viñeta natural, **sin grano ni texturas** [O].

## Sonido
- **[?]** No se puede oír. [D] En los huecos entre palabras el nivel baja a −36/−47 dBFS (voz ≈ −16 dBFS): no hay cama musical fuerte y continua. SFX no verificables.

## Técnicas destacables
1. 0,00–0,16 s — la imagen «aterriza» dentro de la tarjeta con zoom-out + blur [O].
2. 1,3–4,2 s — titular «nada en / tu vida» flanqueando la cara [O].
3. 4,3–5,3 s — «Nada» serif en el sitio del subtítulo + único push-in [O/D].
4. 14,06 s — «excepcional» gigante **detrás de la cabeza** (máscara del sujeto) [O].
5. 42,8 s — 4 aros dorados que se dibujan para «todo sigue girando» [O].
6. 73,9 s — «al / revés» rompe la simetría: solo a la derecha [O].
7. 76,3→77,3 s y 84,6→86,2 s — sustitución en sitio («estático»→«lineal», «mejor»→«peor») [O].
8. 78,9 s — ∞ dorado con destello; cambia de lado al decir «dos direcciones» [O].

## Reglas copiables
- Tarjeta fija al 88 % con radio ≈7 % sobre negro puro; no la muevas.
- Subtítulo pequeño (mayúscula 3 % del alto) al 55 %; bold solo en la palabra clave.
- El subtítulo lleva el arranque de la frase; el remate va en serif a los lados de la cara.
- Un rótulo cada ≈5 s como máximo, y deja tramos de 10–25 s solo con subtítulo.
- Guarda el tamaño gigante (detrás de la cabeza) para una sola palabra del video.
- Para ideas opuestas, sustituye la palabra en el mismo sitio.
- Un solo push-in suave (+4–5 %) en la pausa más dramática; nada de cortes.
- Gráficos: solo línea fina dorada animada, nunca iconos rellenos.
- Nota: en pantalla aparece la errata «desiciones» (9,65 s) [O]; no copiar.
