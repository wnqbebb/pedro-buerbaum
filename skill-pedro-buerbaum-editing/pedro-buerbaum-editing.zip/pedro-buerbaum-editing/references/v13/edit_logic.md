# v13 — lógica de edición: 10 reglas copiables

Formato distinto: horizontal 4:3 (1440×1080), 94,4 s, un solo plano, 0 cortes. Evidencia: [O] observado · [D] derivado · [I] inferido · [?] desconocido.

1. **Todo dentro de una tarjeta fija.** 1270×952 px (88 % del cuadro), radio ≈85–90 px, negro `#000` alrededor; la tarjeta no se mueve en 94 s [D]. Ej.: cualquier fotograma, p. ej. 3,9 s.

2. **Entrada con zoom-out desenfocado.** La imagen baja de 124 % a 102 % en 5 fotogramas (0,00–0,16 s) con blur que se limpia [O]. Es la única «transición» del video.

3. **Un único push-in, en la pausa.** +4,5 % con ease entre 4,2 y 5,2 s, sobre «…Nada.»; no vuelve atrás [D]. El resto es una deriva de +1,7 % en 89 s.

4. **Subtítulo = arranque, serif = remate.** El subtítulo pequeño dice «Así que tomas» y a los lados entra «mejores» (9,33 s) / «desiciones» (9,67 s); igual «Te ve» + «más / gente» (26,0 / 26,3 s) y «atrae al» + «mejor / talento» (41,3 / 41,7 s) [O].

5. **Rótulos flanqueando la cara, palabra a palabra.** Una palabra a cada lado, a 25–40 % del alto, blur-in 0,2–0,28 s clavado a la sílaba (offset típico −0,1…+0,15 s) [O/D]. Duran 0,9–1,7 s.

6. **Palabra sola en el sitio del subtítulo para adjetivos aislados.** «Nada» (4,33–5,3 s) y «sólidas» (53,0–54,0 s) sustituyen al subtítulo en serif ≈2× [O].

7. **Una sola palabra gigante detrás de la cabeza.** «excepcional» a 14,06 s, ancho ≈82 % de la tarjeta, con la cabeza tapando el centro (máscara del sujeto), 1,4 s [O].

8. **Diseño repetido para ideas gemelas.** «Cenas bien / Duermes mejor» (5,7–7,0 s) y «Entrenas bien / Descansas mejor» (44,3–46,0 s) usan el mismo rótulo pequeño de 2 líneas (romana ligera + itálica) [O].

9. **Sustitución en sitio para opuestos y paralelismos.** «Nada es estático» → «lineal» (76,3 → 77,3 s); «mejor» → «peor» (84,6 → 86,2 s); y «al / revés» (73,9 s) rompe la simetría yendo solo a la derecha [O].

10. **Gráficos solo de línea dorada, y solo para la tesis.** 4 aros que se dibujan (42,8–44,3 s, «todo sigue girando») y ∞ con destello (78,9–86,5 s; pasa a la derecha en «dos direcciones», 82,2 s) [O].

## Ritmo y datos rápidos
- Rótulo/gráfico cada ≈5,2 s de media, en rachas: eventos por 10 s = 6,1,1,1,5,2,0,4,3,1 [D].
- Subtítulo: mayúscula 3 % del alto, al 54,5 %, 1–5 palabras (media ≈2,9), clave en bold; palabra a palabra, cada una sube ≈12–15 px de gris a blanco en 0,16–0,2 s [O/D].
- Cierre: «preciso / momento» congelado hasta el último fotograma; sin CTA [O].
- Sonido: [?] no verificable; [D] sin cama musical fuerte (huecos a −36/−47 dBFS frente a voz −16 dBFS).

## 3 rarezas útiles
- 0 cortes y 1 solo cambio de encuadre en 94 s: el ritmo lo ponen los rótulos, no la cámara.
- Texto detrás del sujeto usado una única vez.
- Errata en pantalla («desiciones», 9,67 s): prueba de que los rótulos son manuales [O/I].
