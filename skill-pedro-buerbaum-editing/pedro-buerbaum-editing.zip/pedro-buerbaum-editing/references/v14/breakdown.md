# v14 — desglose (Pedro Buerbaum) · «Audiencia caliente, templada y fría»

Etiquetas de evidencia: **[O]** observado en fotogramas · **[D]** derivado (medido/calculado) · **[I]** inferido · **[?]** desconocido.

## Formato
- Vertical 9:16, 1080×1920, 23,98 fps, 127,2 s, **a pantalla completa** (sin tarjeta, sin bandas) [O].
- Formato propuesto (labels.json dice "?"): **«pizarra/papel a dos cámaras»** — frontal a cámara + cenital sobre un papel donde dibuja con rotulador azul [I].
- **Ningún gráfico de posproducción, ningún rótulo serif, ningún punch-in** [O/D]. La única capa añadida es el subtítulo.

## Estructura del guion
hook-problema «la mayoría de negocios son incapaces de escalar…» (0–4,3 s) → audiencia caliente A.C (4,3–26,5 s) → audiencia templada A.T (26,5–52,8 s) → educarla para que pase a caliente (52,8–67,2 s) → audiencia fría A.F (67,2–87,8 s) → mecanismo de descubrimiento y nutrición (87,8–110 s) → escalar (110–119 s) → cierre «no vivir limitado… boca a boca» (119–127 s). **Sin CTA ni tarjeta final** [O].

## Ritmo
- 23 escenas = 23 planos → **5,5 s/escena** (mín. 1,8 s, máx. 17,3 s) [D].
- **22 cortes secos**, uno cada ≈5,5 s; todos son cambio de cámara frontal ↔ cenital [O/D].
- Cenital (categoría `whiteboard`): 11 planos, 50,1 s = **39 % del video**; dura 1,8–9,9 s (media 4,6 s) y aparece **cada ≈11,5 s** [D].
- Frontal: 12 planos, 77,1 s (61 %), de 2,0 a 17,3 s [D].
- Encuadre dentro del plano: fijo (escala estable ±1–3 %) [D].

## Subtítulos (medidos)
- Sans neo-grotesca regular, blanco `#FFFFFF`, minúsculas, sin caja ni contorno [O]; tipo Helvetica Now/Inter [I].
- Tamaño: mayúscula ≈38 px = **2,0 % del alto** (3,5 % del ancho), cuerpo ≈52 px [D]. Posición: centrado, a **≈59 % del alto** (pecho) [D].
- **1–4 palabras (media ≈2)**; **sin palabra resaltada** (ni bold ni color) [O].
- Bloque estático que cambia por sustitución seca cada ≈1,2 s; no se aprecia animación palabra a palabra [O a 12–25 fps].
- **Defecto**: sobre el papel blanco el subtítulo blanco casi no se lee; no cambia de color ni lleva sombra visible [O].

## El «gráfico»: diagrama dibujado a mano
- Papel blanco-grisáceo `#E3E0E1`, rotulador azul (≈`#2F3F9E`), trazo ≈12–15 px, letra en mayúsculas [O/D].
- Se construye en orden: círculo pequeño + «A.C» (4,3–9,3 s) → círculo grande + «A.T» (31–35,5 s) → recuadro de A.T (≈53 s) → flecha curva A.T→A.C (58,6–67 s) → círculo enorme que se sale del papel + «A.F» (70–76 s) → flecha de fuera hacia A.T (≈100 s) → trazo diagonal hacia fuera (≈115 s) → repaso de A.C (≈120,5 s) [O, ±0,7 s].
- El diagrama queda visible en el borde inferior de todos los planos frontales (continuidad) [O].

## Paleta, grado y texturas
- Luminoso, neutro tirando a frío-verdoso: cortinas sobreexpuestas `#E6E9E4`, camiseta negra `#060505`, piel cálida, azul del rotulador como único acento [O]. Sin grano, viñeta ni texturas añadidas.

## Sonido
- **[?]** No se puede oír. [D] Huecos entre palabras a ≈ −28/−32 dBFS, muy constantes (voz ≈ −16,5 dBFS): hay un fondo estable (ambiente o música baja, no distinguible). SFX no verificables.

## Técnicas destacables
1. 2–4,3 s — baja la vista y empieza a dibujar ANTES del corte: el corte a cenital (4,30 s) queda motivado [O].
2. 4,3–9,3 s — «pequeño núcleo» = círculo pequeño, dibujado mientras lo dice [O].
3. 26,65 s — enmarca el círculo con las manos («un pequeño grupo») antes de dibujar el grande [O].
4. 58,6 s y 64,2 s — la flecha se empieza en un inserto de 1,8 s y se termina en el siguiente, justo en «audiencia caliente» [O].
5. 70,1–75,9 s — el tercer círculo se sale del papel al decir «no me cabría dibujarlo» [O].
6. 43,4 s / 117,5 s — insertos de 2–3 s solo para romper planos largos [O].
7. 119,5 s — vuelve a repasar A.C para cerrar donde empezó [O].

## Reglas copiables
- Dos cámaras fijas (frontal + cenital) y solo corte seco; nada de zoom.
- Corta a la cenital en la palabra que nombra lo que se dibuja; vuelve a cara para explicar.
- Cenital cada ≈10–12 s, de 2 a 10 s; frontales largos permitidos (hasta 17 s) si hay gesticulación.
- El dibujo crece y nunca se borra; déjalo visible en el frontal.
- Haz que el trazo actúe la idea (pequeño, grande, se sale del papel).
- Subtítulo pequeño (mayúscula 2 % del alto) al 59 %, 1–4 palabras, sin resaltar.
- Corregir al copiar: dale color oscuro o sombra al subtítulo sobre el papel blanco.
