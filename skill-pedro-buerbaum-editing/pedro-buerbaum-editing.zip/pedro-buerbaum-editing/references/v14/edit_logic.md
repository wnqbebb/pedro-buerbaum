# v14 — lógica de edición: 10 reglas copiables

Vertical 9:16 completo, 127,2 s, dos cámaras (frontal + cenital sobre papel). Evidencia: [O] observado · [D] derivado · [I] inferido · [?] desconocido. Cortes ±0,04 s; tiempos de trazo ±0,7 s.

1. **Solo corte seco entre dos cámaras fijas.** 22 cortes de 1 fotograma, sin flash, fundido ni zoom [O]. Ej.: 4,30 s (frontal→cenital), 9,34 s (cenital→frontal).

2. **Motiva el corte con la acción.** A los ≈2 s baja la vista y empieza a dibujar; el corte a la cenital llega a 4,30 s, sobre «un pequeño núcleo» (palabra a 4,34 s) [O/D].

3. **Cenital = lo que se nombra se dibuja.** «audiencia caliente» → escribe «A.C» (≈7,3 s); «audiencia templada» → círculo grande + «A.T» (31–35,5 s); «audiencia fría» → «A.F» (≈74,3 s) [O].

4. **Frontal = explicar y convencer.** Los planos a cámara cargan la explicación larga: 9,34–26,65 s (17,3 s) y 75,91–87,84 s (11,9 s), solo con subtítulo [O/D].

5. **Cadencia de la cenital.** 11 planos cenitales, cada ≈11,5 s, de 1,8 a 9,9 s (media 4,6 s) = 39 % del video [D]. Eventos por 10 s = 2,0,1,1,2,3,3,2,1,2,2,2,1.

6. **Insertos cortos para sostener el ritmo.** Cenital de 3,1 s solo señalando (43,42–46,51 s) y de 1,8 s empezando la flecha (58,60–60,35 s); frontal de 2,0 s (117,45–119,45 s) [O].

7. **Trazo partido en dos planos.** La flecha A.T→A.C se inicia en 58,6 s y se termina en 64,19–67,15 s, llegando a «A.C» al decir «audiencia caliente» (65,9–66,4 s) [O].

8. **El dibujo actúa la frase.** Manos enmarcando el círculo en «un pequeño grupo» (26,65 s); tercer círculo fuera del papel en «ni siquiera me cabría dibujarlo» (70,07–72 s); trazo hacia fuera en «escalar» (≈115 s) [O].

9. **Continuidad del diagrama.** Nunca se borra; se ve crecer en el borde inferior de cada plano frontal (1, 2 y 3 círculos) y el cierre vuelve a repasar «A.C» (≈120,5 s) [O].

10. **Subtítulo mínimo y neutro.** Sans regular blanca, mayúscula 2,0 % del alto, al 59 %, 1–4 palabras (media ≈2), bloque estático, sin palabra resaltada [O/D].

## Datos rápidos
- Sin rótulos, sin iconos, sin tarjeta, sin punch-in (escala estable ±1–3 %) [D].
- Cierre a cámara en «…la gente que te recomienda» (127,2 s), sin CTA [O].
- Sonido: [?] no verificable; [D] fondo estable ≈12–16 dB por debajo de la voz (ambiente o música baja).

## 3 rarezas útiles
- Es el caso «casi sin editar»: toda la gráfica es real y a mano.
- El subtítulo blanco sobre papel blanco es casi ilegible en la cenital (defecto a corregir) [O].
- Planos frontales de hasta 17 s sin un solo cambio de encuadre.
