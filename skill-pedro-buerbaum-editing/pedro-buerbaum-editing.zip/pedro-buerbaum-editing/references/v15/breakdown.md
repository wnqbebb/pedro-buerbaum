# v15 — desglose (Pedro Buerbaum) · «Las 5 métricas del engranaje de conversión»

Etiquetas de evidencia: **[O]** observado en fotogramas · **[D]** derivado (medido/calculado) · **[I]** inferido · **[?]** desconocido.

## Formato
- Cuadro vertical 9:16, 1080×1920, 23,98 fps, 131,3 s [O].
- El video ocupa **1080×1242 px (≈5:6)**: 100 % del ancho × 64,7 % del alto, de y=340 a y=1582; **bandas negras `#000`** arriba (17,7 %) y abajo (17,6 %); **esquinas rectas** (no es tarjeta redondeada) [D].
- **Título fijo todo el video** en la banda superior: «Tienes más oportunidades de las que crees» [O].
- Formato propuesto (labels.json dice "?"): **«pizarra a dos cámaras con título fijo»** [I].
- Categorías: uso `aroll_caption` / `whiteboard` según el contenido y anoto el encuadre reducido en `framing` (no es `card_video` porque no hay tarjeta redondeada ni cambia de tamaño).

## Estructura del guion
hook «si solo estás teniendo en cuenta tu número de ventas…» (0–5,6 s) → promesa: las métricas (5,6–15 s) → 1 leads (15–31,5 s) → 2 speed to lead + estudio MIT ×100 (31,5–64 s) → 3 show up rate (64–86,7 s) → 4 tasa de conversión (86,7–102,4 s) → 5 lifetime value (102,4–127,6 s) → cierre «tenemos que medirlo… muy importante» (127,6–131,3 s). **Sin CTA** [O].

## Ritmo
- 17 escenas = 17 planos → **7,7 s/escena** (mín. 1,2 s, máx. 17,1 s) [D].
- **16 cortes secos**, uno cada ≈7,7 s; todos frontal ↔ cenital [O/D].
- Cenital (`whiteboard`): 8 planos, 74,3 s = **57 % del video**; duran 2,0–16,1 s (media 9,3 s), uno cada ≈16 s [D].
- Frontal: 9 planos, 57,1 s (43 %) [D]. Encuadre fijo (escala 1,000 en todos los planos) [D].

## Título fijo (medido)
- Sans neo-grotesca **semibold**, blanco, una línea, mayúscula ≈30 px (1,6 % del alto), ancho ≈75 % del cuadro (x 135–946), y ≈287–328 px (15–17 % del alto), a ≈12 px del borde superior del video [D]. No se anima nunca [O].

## Subtítulos (medidos)
- Sans neo-grotesca regular, blanco, minúsculas, sin caja [O]; mayúscula ≈37 px = **1,9 % del alto del cuadro** (3,4 % del ancho), cuerpo ≈50 px [D].
- Posición: centrado, a **≈55 % del alto del cuadro** (≈58 % dentro del video, sobre el pecho) [D].
- **1–4 palabras (media ≈2,2)**; sin palabra resaltada [O]. Bloque estático que cambia por sustitución cada ≈1,3 s [O].
- **Defecto**: blanco sobre pizarra blanca → casi ilegible en la cenital [O].

## El «gráfico»: pizarra real
- Pizarra blanca `#D1CECC` con marco, rotulador azul, mayúsculas a mano, trazo ≈10–14 px [O].
- Orden: «N.V» subrayado (2–5 s) → «LEADS» + ↓↓ (15–24 s) → «→ SPEED TO L.» (33–39 s) → «5' → 30'» y «X100» (47,8–55 s) → flecha curva + «% SHOW» + 3 guiones (67,5–79 s) → «→ % C.V.» + 3 guiones (87–98 s) → «→ LTV.» (108,5–110,4 s) → recuadro de LTV (≈127,7 s) [O, ±0,7 s].
- Cada vuelta a la cenital **reencuadra** la zona nueva de la pizarra [O].

## Paleta, grado y texturas
- Luminoso neutro-frío verdoso (cortinas `#E8ECE5`), camiseta negra `#030303`, azul del rotulador como único acento, negro puro en las bandas [O]. Sin grano ni texturas añadidas.

## Sonido
- **[?]** No se puede oír. [D] Huecos a −35 dBFS de mediana (voz ≈ −17 dBFS); los más ruidosos (−24/−26 dBFS a 15,7, 36,0, 37,9 y 70,0 s) coinciden con planos de escritura → probable roce del rotulador [I]. Música no verificable.

## Técnicas destacables
1. 0 s — título fijo como hook permanente + primera pizarra antes de los 2 s (corte a 1,88 s) [O].
2. 1,9–5,6 s — «N.V» se escribe primero y luego se deja a un lado: el diagrama acaba volviendo a él [O].
3. 46,8–61,7 s — el dato ×100 se escribe cifra a cifra en un plano de 14,9 s [O].
4. 61,65 s — inserto frontal de 2,3 s («Eso es realmente impresionante») entre dos pizarras largas [O].
5. 63,9–80,1 s — flecha curva que baja de fila = «lo que viene después» [O].
6. 102,4–108,5 s — vuelve a cara para crear curiosidad antes de la última métrica; «LTV» se revela en 2 s [O].
7. 127,6 s — recuadro final sobre «LTV.» en «tenemos que medirlo» [O].

## Reglas copiables
- Video al 100 % de ancho y ≈65 % de alto sobre negro, con un título fijo de una línea encima.
- Dos cámaras fijas, solo corte seco, un corte cada ≈7–8 s.
- Pizarra ≈55–60 % del tiempo; deja planos de escritura largos (10–16 s) cuando hay cifras.
- Una métrica = un rótulo escrito + flecha a la siguiente; guiones para las sub-ideas.
- Vuelve a cara para puentes, opiniones y enumeraciones largas.
- Subtítulo pequeño (mayúscula ≈1,9 % del alto) al 55 %, 1–4 palabras, sin resaltar.
- Corregir al copiar: subtítulo legible sobre la pizarra (oscuro o con sombra).
