# v15 — lógica de edición: 10 reglas copiables

Cuadro 9:16 con video 1080×1242 sobre negro y título fijo; 131,3 s; dos cámaras (frontal + cenital de pizarra). Evidencia: [O] observado · [D] derivado · [I] inferido · [?] desconocido. Cortes ±0,04 s; tiempos de escritura ±0,7 s.

1. **Título fijo encima del video.** «Tienes más oportunidades de las que crees», sans semibold blanca, una línea, 75 % del ancho, en la banda negra superior (y 15–17 %), desde el fotograma 0 hasta el final sin animar [O/D].

2. **Video encogido solo en altura.** 100 % del ancho × 64,7 % del alto (y 340–1582), bandas negras de ≈17,6 % arriba y abajo, esquinas rectas [D].

3. **Pizarra antes de los 2 s.** Corte a la cenital a 1,88 s; «N.V» escrito a ≈2–3 s mientras dice «número de ventas» (2,38–2,84 s) [O/D].

4. **Solo corte seco entre dos cámaras fijas.** 16 cortes de 1 fotograma, sin zoom (escala 1,000 en cada plano) [O/D]. Eventos por 10 s = 2,1,1,2,1,0,2,0,2,0,2,1,1,1.

5. **Una métrica = un rótulo + una flecha.** «LEADS» (15,3–19 s) → «SPEED TO L.» (33–39 s) → «% SHOW» (70,5–73,5 s) → «% C.V.» (87–89 s) → «LTV.» (108,5–110,4 s), siempre unidos por flechas [O].

6. **Las cifras se escriben en plano largo.** 46,76–61,65 s (14,9 s): «5'» (≈47,8 s), «→ 30'» (≈49,5 s), «X100» subrayado (52,5–55 s), siguiendo «cinco minutos… 30 minutos… por cien» [O].

7. **Guiones para sub-ideas.** Tres guiones bajo «% SHOW» (≈78 s, «sistemas de recordatorios») y bajo «% C.V.» (93–98 s, «script… producto… equipo») [O].

8. **Cara para puentes y curiosidad.** Insertos frontales cortos: 61,65–63,94 s («Eso es realmente impresionante») y 102,44–108,48 s («algo de lo que se olvidan…») antes de revelar LTV en 2 s (108,48–110,44 s) [O].

9. **Reencuadre de la pizarra en cada vuelta.** La cenital se recoloca para centrar lo nuevo: zona izquierda (15 s), centro (47 s), fila de abajo (64 s), derecha (87 s y 108 s) [O].

10. **Cierre con recuadro y frase seca.** Recuadra «LTV.» a ≈127,7 s («tenemos que medirlo») y corta a cara para «muy importante» (130,17–131,35 s); sin CTA [O].

## Datos rápidos
- Cenital: 8 planos, 74,3 s (57 %), media 9,3 s; frontal: 9 planos, 57,1 s [D].
- Subtítulo: sans regular blanca, mayúscula 1,9 % del alto, al 55 % del cuadro, 1–4 palabras (media ≈2,2), bloque estático, sin resaltar [O/D].
- Sonido: [?] no verificable; [D/I] los huecos más ruidosos coinciden con escritura (roce del rotulador).

## 3 rarezas útiles
- Título fijo permanente = el hook no desaparece nunca.
- La pizarra ocupa más tiempo que la cara (57 %).
- Subtítulo blanco sobre pizarra blanca casi ilegible (defecto a corregir) [O].
