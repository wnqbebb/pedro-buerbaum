# v16 — desglose (Pedro Buerbaum) · «Ganar dinero son 2 pasos»

Etiquetas de evidencia: **[O]** observado en fotogramas · **[D]** derivado (medido/calculado) · **[I]** inferido · **[?]** desconocido.

## Formato
- **FORMATO DISTINTO: casi cuadrado, 1080×1034, 25 fps, 84,3 s** [O]. Grabado en el asiento trasero de un coche, gafas de sol, camiseta negra sin mangas.
- Formato propuesto (labels.json dice "?"): **«busto en tarjeta (coche) + rótulos serif de estructura + 1 gráfico completo»** [I].
- **Tarjeta redondeada fija** 1019×745 px = 94,4 % del ancho × 72 % del alto; bandas negras de 145 px (14 %) arriba y abajo; radio ≈85 px (≈8 % del ancho de tarjeta); borde levemente difuminado; fondo `#000000` [D].

## Estructura del guion
hook «Vamos a ver… ganar dinero… son 2 pasos» (0–7,2 s) → paso 1: tener algo que aportar (7,3–13,6 s) → gráfico valor→dinero (13,6–16,9 s) → error de la mayoría: mejorar y mejorar (16,9–29,2 s) → paso 2: salir del punto de partida, «Eres invisible» (29,2–45,4 s) → dos alternativas: arpón (48–66 s) y red = contenido (66–82,8 s) → remate «de forma masiva» (82,8–84,3 s). **Sin CTA** [O].

## Ritmo
- 24 escenas en 84,3 s → **3,5 s/escena** [D].
- Solo **3 cortes** (7,24 / 13,60 / 16,88 s); el resto son zooms animados [O/D].
- **Cambio de encuadre apreciable cada ≈7–8 s de media**, en rachas: 33–46 s casi continuo (1,15–1,6×); 17–33 s y 46–62 s plano base quieto [D, ±0,05].
- **Rótulo/icono/gráfico cada ≈9 s** (9 en 84 s). Gráfico completo: 1 vez, **3,3 s** (3,9 % del video) [D].

## Subtítulos (medidos)
- Sans neo-grotesca regular, blanco, sin caja [O]; mayúscula ≈27 px = **2,6 % del alto del cuadro** (3,6 % de la tarjeta), cuerpo ≈38 px [D].
- Posición: centrado, a **≈61 % del alto del cuadro** (≈65 % dentro de la tarjeta, sobre el pecho) [D].
- **1–6 palabras (media ≈2,6)**, a veces 2 líneas con la segunda en bold («de **ganar dinero**») [O].
- Palabra a palabra: entra gris y algo más baja, sube a blanco en ≈0,15–0,2 s [O].
- **Cita = itálica con comillas** («“Hola / estoy aquí / y tengo esto / que ofrecer”», 41,0–45,3 s) [O].

## Rótulos, iconos y gráfico
- Serif display itálica de alto contraste, blanca (tipo PP Editorial New Italic [I]): «Vamos a ver» (0,0 s), «2 pasos» (6,55 s, altura total ≈13 % del alto), «el segundo paso» (29,1 s). **Siempre cabalgando el borde superior de la tarjeta**, mitad sobre el negro [O].
- «aportar» (10,0 s): última palabra en serif ≈2,5× bajo el subtítulo [O].
- «Eres invisible» (32,92 s): **sans bold** ≈3× el subtítulo, blur-in de 5 fotogramas, con punch-in a 1,6× [O/D]. «de forma masiva» (83,2 s): sans bold ×1,5.
- Iconos de **línea** blancos (trazo ≈5–6 px, ≈135 px) bajo el subtítulo: arpón (48,6–52,5 s) y red (67,1–69,4 s) [O].
- Gráfico completo (13,60–16,88 s): negro `#000` + cuadrícula blanca de ≈2 px deformada (9×6 celdas) + iconos **macizos** blancos con glow: bombilla → flecha de tiza (barrido 14,5–15,2 s) → mano con billete (15,6 s); subtítulo abajo (≈80 % del alto) [O].

## Paleta, grado y texturas
- Neutro-frío desaturado: cielo gris `#CED0CF`, interior `#050607`/`#2F2D2C`, piel cálida; contraste alto; sin grano [O]. Textura solo en el gráfico (tiza, glow).

## Sonido
- **[?]** No se puede oír. [D] Huecos entre palabras a −31/−45 dBFS (voz ≈ −17 dBFS), con dos huecos ruidosos (20,2 y 53,8 s, −17/−19 dBFS) de origen desconocido. Música y SFX no verificables.

## Técnicas destacables
1. 0,0 s — muletilla «Vamos a ver» convertida en titular serif desde el fotograma 0 [O].
2. 6,55 s — «2 pasos» sobre el borde de la tarjeta + gesto de dos dedos [O].
3. 7,24 s — punch-in por corte (≈1,24×) para abrir capítulo [D].
4. 13,60 s — corte seco a ecuación de iconos que se construye con la frase [O].
5. 32,92 s — «Eres invisible» + punch-in 1,6× (el golpe del video) [O/D].
6. 41,0 s — subtítulo en cursiva con comillas mientras interpreta la cita [O].
7. 48,6 y 67,1 s — pareja de iconos (arpón / red) en la misma posición [O].
8. 83,2 s — cierre: la última frase crece a bold ×1,5 en el sitio del subtítulo [O].

## Reglas copiables
- Tarjeta al 94 % × 72 % con radio ≈8 %; deja que los rótulos de capítulo se salgan por arriba.
- Serif itálica solo para estructura (2 pasos, segundo paso); sans bold grande solo para el golpe.
- Un gráfico completo breve (≈3 s) para la definición central; 3 elementos que entran en orden.
- Metáforas menores → icono de línea pequeño bajo el subtítulo, no gráfico completo.
- Zooms animados (ease 0,3–0,8 s) en vez de cortes; punch-in fuerte solo una vez.
- Cambia el subtítulo a cursiva con comillas cuando el orador «actúa» una cita.
- Termina en la última palabra, más grande; sin tarjeta final.
