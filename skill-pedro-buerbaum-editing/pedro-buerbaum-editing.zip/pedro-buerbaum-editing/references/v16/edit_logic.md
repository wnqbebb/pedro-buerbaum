# v16 — lógica de edición: 10 reglas copiables

Formato distinto: casi cuadrado (1080×1034), 84,3 s, coche. Evidencia: [O] observado · [D] derivado · [I] inferido · [?] desconocido. Escalas de zoom ±0,05 (las manos tapan el fondo).

1. **Tarjeta fija con bandas negras.** 1019×745 px (94,4 % × 72 %), radio ≈85 px, 145 px de negro arriba y abajo [D]. El negro superior sirve de «techo» para los rótulos.

2. **Rótulos de estructura sobre el borde superior.** Serif itálica blanca cabalgando el borde de la tarjeta: «Vamos a ver» (0,00–0,6 s), «2 pasos» (6,55–7,24 s), «el segundo paso» (29,1–30,2 s) [O]. Entran con blur-in ≈0,15 s, palabra a palabra.

3. **Cifra + gesto.** «2 pasos» entra a 6,55 s, entre «dos» (6,14) y «pasos» (6,80), justo cuando levanta dos dedos [O/D].

4. **Capítulo nuevo = punch-in por corte.** 7,24 s: salto a ≈1,24× al empezar «El primer paso»; se mantiene hasta el gráfico [D].

5. **Última palabra en serif bajo el subtítulo.** «es tener algo que» + «aportar» ≈2,5× a 10,0 s (−0,12 s respecto a la palabra) [O].

6. **Un gráfico completo, corto y construido con la frase.** Corte seco a 13,60 s: cuadrícula blanca deformada sobre negro + bombilla; flecha por barrido 14,5–15,2 s («y estoy aquí»); mano con billete 15,6 s («para intercambiarlo»); corte de vuelta 16,88 s [O]. 3,3 s en total.

7. **Volver del gráfico con zoom-out.** El A-roll reaparece en ≈1,23× y se abre a 1,00 en 0,5 s (16,88–17,4 s) [D].

8. **El golpe: sans bold + punch-in fuerte.** «Eres invisible» blur-in de 5 fotogramas (32,92–33,10 s) y zoom 1,00→1,60 en ≈0,3 s; debajo «nadie te conoce» a 34,3 s; luego zoom-out lento [O/D].

9. **Cita en cursiva con comillas.** De 41,0 a 45,3 s el subtítulo pasa a itálica: «“Hola», «estoy aquí», «y tengo esto», «que ofrecer”», con la cámara a ≈1,55→1,30× [O/D].

10. **Pareja de iconos de línea para dos alternativas.** Arpón bajo el subtítulo 48,62–52,5 s (3,9 s) y red 67,1–69,4 s (2,3 s), mismo sitio y mismo trazo (≈5–6 px) [O].

## Ritmo y datos rápidos
- 3 cortes en 84 s; eventos por 10 s = 3,5,1,3,4,0,3,0,1 [D].
- Zooms animados: 33,0 (in 1,6×), 37,6 (out), 38,2 (in lento), 40,6 (in 1,55×), 45,4 (out), 62,2 (in 1,34×), 65,8 (out) [D].
- Subtítulo: mayúscula 2,6 % del alto, al 61 % del cuadro, 1–6 palabras (media ≈2,6), palabra a palabra gris→blanco ≈0,15–0,2 s [O/D].
- Cierre: «de forma masiva» en bold ×1,5 (83,2 s) y fin; sin CTA [O].
- Sonido: [?] no verificable; [D] sin cama musical fuerte evidente.

## 3 rarezas útiles
- Rótulos que se salen de la tarjeta por arriba (mitad sobre negro).
- Subtítulo que cambia de estilo (cursiva + comillas) para marcar estilo directo.
- Dos familias con roles distintos: serif itálica = estructura; sans bold grande = golpe y cierre.
