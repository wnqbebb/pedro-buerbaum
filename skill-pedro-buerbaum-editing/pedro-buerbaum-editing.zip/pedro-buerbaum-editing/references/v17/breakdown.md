# v17 — breakdown
**Formato propuesto** (labels.json dice "?"): `whiteboard_split` — pantalla partida fija: busto arriba + pizarra cenital abajo, título fijo, sin cortes. Justificación: 1 solo plano en 132.6 s y las dos cámaras visibles a la vez en todos los fotogramas (*observado*).

**Guion**: hook (0–3.5: 'todos ponen el foco en el paso final') → problema (3.5–20.9: obsesión con el cierre) → giro (20.9–28.7: 'hay que ir más atrás') → paso 1 Cualificación (28.7–52.2) → paso 2 Educación (52.2–74.3) → paso 3 Propuesta (74.3–100.6) → recap (100.6–113.6) → payoff 'el cierre es consecuencia' (113.6–124) → cierre sin CTA (124–132.6).

**Ritmo**: 21 escenas / 132.6 s = 6.3 s por escena (*derivado*); son beats de dibujo, no cortes. 0 cortes, 0 cambios de encuadre. Evento de dibujo cada ≈6 s.

**Mediciones** (1080×1920)
- Lienzo negro #000000 (medido). Banda de imagen y=290–1659 (1369 px, 71 % del alto), ancho completo, esquinas rectas (no hay tarjeta redondeada).
- Costura cámara frontal / cenital en y≈935: frontal ≈645 px (47 %), pizarra ≈724 px (53 %) (*derivado*).
- Título: sans regular blanca, ≈25 px de alto (1.3 %), x=171–911 (69 % del ancho), y≈243–268, fijo todo el video.
- Subtítulo: sans regular/medium blanca con sombra suave, altura de mayúscula ≈36 px (1.9 %), 1–3 palabras (media ≈1.8), centrado, sobre la costura (48–49 % del alto). No resalta ninguna palabra, sin color de acento. Entrada/salida por sustitución seca.
- Gráficos: solo pizarra real; trazo de rotulador ≈10–12 px (estimado). Ningún gráfico digital, ninguna tarjeta, ningún b-roll.
- Encuadre: cambia 0 veces. Gráfico (pizarra) presente el 100 % del tiempo; se añade un trazo cada ≈6 s.
- Color: high-key, blancos cremosos, cortinas verde pálido, piel cálida, contraste bajo-medio, sin grano.
- Sonido: desconocido (no audible para el análisis). RMS: piso ≈ −50 dB → probablemente solo voz (*inferido*).

**Técnicas destacables**
1. 3.0–9.0 dibuja primero la caja final 'C' a la derecha.
2. 21.8 arco hacia atrás en 'más atrás'.
3. 52.5→60.0 caja vacía antes de nombrarla ('E').
4. 65.8–70.3 un guion por cada 'para ser conscientes'.
5. 84–99 lista de líneas onduladas bajo 'P'.
6. 102–116 recap con mini-arcos caja a caja.
7. 124–129 gesto grande de manos como único 'efecto' de énfasis.

**Reglas copiables**
- Si hay pizarra: split fijo 47/53, subtítulo en la costura, título fijo arriba en la barra negra.
- No cortar: que el ritmo lo ponga el trazo (1 trazo por idea, ≈cada 6 s).
- Dibujar el final primero y rellenar hacia atrás.
- Una marca por elemento de lista hablado.
- Recorrer el diagrama completo con el rotulador antes del cierre.
- Categorías: `whiteboard` = está dibujando; `aroll_caption` = habla sin dibujar (el encuadre sigue siendo split); `title_cta` final = cierre sin CTA.
