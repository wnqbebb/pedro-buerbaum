# v17 — lógica de edición (10 reglas copiables)
Formato: pantalla partida fija (busto arriba, pizarra cenital abajo), título fijo, 0 cortes. Precisión de los trazos ±0.75 s.

1. **Split permanente, sin cortes** (0.0–132.6): banda de imagen y=290–1659 px (71 % del alto) sobre negro #000; arriba cámara frontal (≈47 %), abajo cenital (≈53 %). *observado/derivado*
2. **Título fijo en la barra negra superior** todo el video: 'El error que está matando tus ventas', sans regular blanca ≈25 px (1.3 % del alto), y≈243–268. *observado*
3. **Subtítulo en la costura** de las dos cámaras (y≈908–945, 48–49 % del alto): sans blanca ≈36 px, 1–3 palabras, sin palabra destacada, sustitución seca cada ≈0.75 s. *observado/derivado*
4. **Empieza por el final**: en 'foco… paso final' (3.0) dibuja la caja de la derecha y en 'cierre' (8.6) escribe C; el hueco de la izquierda es la promesa del video. *observado*
5. **'Más atrás' = flecha hacia atrás** (21.8): arco grande de derecha a izquierda; el giro del guion se dibuja como movimiento espacial. *observado*
6. **Caja antes que nombre**: la caja vacía aparece (52.5) ≈7.5 s antes de escribir la letra 'E' en 'educativo' (60.0). Abre bucle. *observado*
7. **Un trazo por elemento de lista**: guiones bajo E en cada 'para ser conscientes de…' (65.8, 67.3, 68.8, 70.3); líneas onduladas bajo P en cada promesa (84.0→99.0). *observado*
8. **Alterna dibujar / mirar a cámara**: tramos sin trazo (9.5–13.8, 32.4–36.7, 42.9–52.2, 80.0–83.9) sirven de pausa; el dibujo nunca dura más de ≈17 s seguidos. *derivado*
9. **Recap recorriendo el diagrama** (102.0–116): mini-arcos C→E, E→P, P→C sincronizados con 'has hecho bien… has nutrido… has sabido presentar… el cierre'. *observado*
10. **Sin CTA ni outro**: termina en 'y natural' (132.0) con el diagrama completo y corte seco. *observado*

Sonido: no se ve ningún SFX; piso de ruido ≈ −50 dB en silencios → probablemente solo voz, sin música o muy baja (*derivado de RMS; inferido*).
Color: high-key cálido-neutro, blancos cremosos, tinta azul rey; sin grano ni viñeta (*observado*).
Desconocido: fuente exacta, si hay música, modelo de cámaras.
