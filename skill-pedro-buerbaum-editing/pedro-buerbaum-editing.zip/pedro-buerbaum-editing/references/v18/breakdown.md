# v18 — breakdown
**Formato propuesto** (labels.json "?"): `whiteboard_split_con_insertos` — título fijo + pizarra en split + insertos de cámara cercana y de texto sobre blanco. Justificación: 11 planos, 3 diseños alternos (*observado*).

**Guion**: hook 'No puedes decir…' (0–1) → lo que NO (clichés tachados, 1–9.3) → lo que SÍ: resultado concreto (9.3–14.9) → + time frame (14.9–31.8) → + mecanismo único (31.8–43.8) → objeción '¿cómo lo haces? ¿qué te diferencia?' (43.8–47.8) → ejemplo dieta (47.8–69.4) → + red de seguridad/garantía (69.4–98) → consejo 'tu propia garantía' (98–102) → payoff 'oferta ganadora' (103–108) → cierre 'no competir por precio' (108–112). Sin CTA.

**Ritmo**: 22 escenas / 112.2 s = 5.1 s por escena (*derivado*); 10 cortes (5.4/min). Primeros 9 s: 3 cambios de diseño. Cambio de encuadre: cada ≈11 s de media, pero muy desigual (0.4 s … 50 s).

**Mediciones** (1080×1920)
- Lienzo #000000. Banda de imagen y=320–1602 (1282 px = 67 % del alto), ancho completo, esquinas rectas (no es tarjeta redondeada).
- Split: costura y=894 → frontal 574 px (45 %), pizarra 708 px (55 %).
- Título: 'Tu oferta suena igual que todas', sans regular blanca ≈26 px (1.4 %), x=242–839, y≈275–301, fijo.
- Subtítulo full: sans regular/medium blanca con sombra, mayúscula ≈38 px (2.0 %), 1–3 palabras, centro y≈1075 (56 %). En split: sobre la costura (≈46 %). Conserva “comillas” y ¿?. Palabra destacada: solo 'garantía' (negrita ≈1.6×, blur-in).
- Gráficos digitales: 2 en 112 s (uno cada ≈56 s), duran 5.4 s y 2.75 s. Fondo blanco roto #FBF9F7 con bordes laterales grises; texto negro sans; trazos a mano ≈3–4 px.
- Entradas/salidas: todo corte seco; dentro del gráfico blur+gris→negro (0.3 s) y trazos write-on (0.3–0.8 s).
- Color: high-key, cálido-neutro, contraste bajo-medio, sin grano.
- Sonido: desconocido (no audible); RMS sugiere solo voz (*inferido*).

**Técnicas destacables**
1. 1.04–5.9 lista de clichés tachados uno a uno.
2. 5.95 'NO' con subrayado ondulado (0.5 s).
3. 9.09 pizarra con fórmula pre-escrita que se completa (+TF 16.0, −20 22.0, CLAR 27.5, +M.U 35.5, −10K 41.0, +RED SEG 71.0).
4. 43.79 corte de 0.9 s a cámara cercana para la objeción.
5. 44.70 cartel en negrita con elipse, flecha en bucle y subrayado dibujados.
6. 47.45 puente de 0.4 s.
7. 100.6 'garantía' en negrita.
8. 103–108 círculo final sobre 'O.G'.

**Reglas copiables**
- Abrir con la cara 1 s y cortar a texto que ilustre literalmente la lista.
- Tachar en vez de borrar; rematar con una palabra sola.
- Texto digital siempre sobre blanco roto, negro, con garabatos a mano; la pizarra real para la parte constructiva.
- Cámara cercana solo para frases dirigidas al espectador (objeción, consejo, cierre).
- Máximo una palabra en negrita por video.
- Nota de categorías: `full_graphic` aquí es sobre blanco (no negro); `aroll_punch` = cambio a cámara cercana; `title_cta` = cierre sin CTA.
