# v18 — lógica de edición (10 reglas copiables)
Formato: título fijo + 3 diseños alternos (cámara cercana full / split con pizarra / gráfico de texto sobre blanco). Todo por corte seco.

1. **Hook en 1 s y gráfico inmediato**: 'No puedes decir' a cámara (0.0–1.04) → corte a lista escrita (1.04). *observado*
2. **Lista de clichés que se tachan**: cada frase entre comillas entra gris+blur→negro en 0.3 s (1.04, 1.97, 3.7, 4.7) y se tacha con raya que se dibuja en ≈0.5 s cuando empieza la siguiente (2.4, 3.5, 4.5, 5.25). *observado*
3. **Remate de una palabra**: 'NO' + subrayado ondulado dibujado (5.95–6.48, 0.5 s) y corte a la cara. *observado*
4. **Lo malo en gráfico, lo bueno en pizarra**: al decir 'Es…' (9.34) corta a split con la fórmula ya empezada (corte 9.09, −0.25 s). *observado*
5. **Split**: banda y=320–1602 (67 % del alto); frontal 45 % arriba, pizarra 55 % abajo; subtítulo sobre la costura (≈46 % del alto). *medido*
6. **Full**: misma banda, cámara cercana; subtítulo ≈38 px (2 %), 1–3 palabras, centro a ≈56 % del alto (pecho). *medido*
7. **Objeción del cliente = corte a cámara cercana** de 0.9 s ('¿Pero cómo lo haces?', 43.79) seguido de cartel '¿Qué te diferencia de los demás?' en negrita con elipse dibujada (44.70–47.45). *observado*
8. **Puente de 0.4 s** de cara ('Bien, pues', 47.45–47.84) entre gráfico y pizarra: nunca corta gráfico→pizarra directo. *observado*
9. **Una sola palabra destacada**: 'garantía' en negrita ≈1.6× con blur-in 0.2 s (100.6), dura ≈1 s. *observado*
10. **Cierre a la cara sin CTA**: corte a cámara cercana 0.2 s antes de 'simplemente' (108.32); termina en 'por precio'. *observado*

Ritmo: 10 cortes/112 s; bloques de pizarra de 34.7 s y 50.1 s sin corte; 2 gráficos digitales (5.4 s y 2.75 s).
Sonido: desconocido; piso RMS ≈ −45 dB → probablemente sin música o muy baja (*inferido*). No se puede confirmar whoosh/clic en los tachados.
Color: high-key cálido; gráficos #FBF9F7 con bordes grises; lienzo #000.
