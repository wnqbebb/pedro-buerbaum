# v19 — breakdown
**Formato propuesto** (labels.json "?"): `busto_full_minimal` — busto parlante a sangre, plano único, subtítulo diminuto y un overlay de texto. Justificación: 1 plano en 34.8 s, sin barras ni título (*observado/medido*).

**Guion**: hook-orden ('olvídate del fucking multitasking', 0–2.4) → situación ('20 ventanas… soy multitasker, Pedro', 2.4–10.1) → consecuencia ('no te concentras en nada', 10.1–13.9) → concepto (DEEP WORK, 13.9–18.1) → beneficio ('ejecutar literalmente todo', 18.1–24.1) → instrucción 1 ('entrar en foco rápido', 24.1–31.3) → instrucción 2/cierre ('bloques de trabajo profundo', 31.3–34.8). Sin CTA.

**Ritmo**: 11 escenas / 34.8 s = 3.2 s por escena (*derivado*). Cambios de encuadre confirmados: 2 (15.3 push-in, 16.9 zoom-out) + 2 dudosos (0.85, 20.2–21.4).

**Mediciones** (1080×1920)
- Encuadre a sangre: sin barras, sin tarjeta.
- Subtítulo: sans fina blanca, minúsculas, ≈30 px (1.6 %), 1–3 palabras (media ≈1.6), y=1073–1105 (56.7 %), ancho 110–225 px (10–21 %). No resalta ninguna palabra. Sustitución seca; se apaga en pausas.
- Overlay 'DEEP' / 'WORK': extra-bold mayúsculas blanca, 68 px (3.5 %), y=970–1038 (52 %), x=146–404 y 619–916; blur-in 0.2 s; dura ≈2.6 s; 1 vez en 34.8 s.
- Zoom: 1.0→≈1.15× en 0.25 s (15.3), vuelta en 0.3 s (16.9).
- Fundido final a negro ≈0.4 s (34.4–34.8).
- Color: frío (teal/azul-gris), contraste medio-alto, negros aplastados, fondo desenfocado, sin grano visible.
- Sonido: desconocido; RMS sugiere cama continua (música/ambiente) (*inferido*).

**Técnicas destacables**
1. 0.1–0.7 gesto de barrido como hook visual.
2. 3.1 manos abiertas en 'ventanas abiertas'.
3. 15.2/15.8 'DEEP' 'WORK' a los lados del cuerpo.
4. 15.3–17.2 push-in y vuelta enmarcando el concepto.
5. 20.2–21.3 pausa sin subtítulo.
6. 34.4 fundido a negro.

**Reglas copiables**
- En piezas de ≤35 s: 1 solo gráfico, colocado hacia el 40–50 % de la duración.
- Texto grande partido en dos para no tapar la cara ni el subtítulo.
- Zoom solo mientras el texto grande está en pantalla.
- Subtítulo 1.6 % del alto, minúsculas, sobre la zona más oscura (camiseta).
- Nota de categorías: no hay `hook_title` (no existe texto de gancho); `title_cta` final = cierre sin CTA.
Evidencia extra de audio (derivado de audio/no_vocals.wav ya existente): pista sin voz constante a ≈ −34 dB con subidas de ≈3 dB cada ≈8 s (0.5–2, 8–10, 16–18, 24.5–26, 32–34 s) → cama musical/ambiente en bucle de ≈8 s, baja; sfx_events.json está vacío → ningún SFX discreto detectado (ni en el zoom de 15.3).
