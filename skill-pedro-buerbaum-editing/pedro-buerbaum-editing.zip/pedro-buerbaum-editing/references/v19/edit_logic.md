# v19 — lógica de edición (10 reglas copiables)
Formato: busto a sangre, un plano, subtítulo diminuto, un único texto grande.

1. **Arranque en frío** (0.0): sin título; primer fotograma ya con subtítulo 'olvídate' y un gesto que cruza el cuadro (0.1–0.7). *observado*
2. **Subtítulo mínimo**: sans fina blanca en minúsculas, ≈30 px (1.6 % del alto), 1–3 palabras, centro a 56.7 % del alto (y 1073–1105), sobre la camiseta negra. *medido*
3. **Sin palabra destacada en el subtítulo**: el énfasis se hace con un overlay aparte. *observado*
4. **Un solo beat gráfico por video corto**: 'DEEP' (15.2) y 'WORK' (15.8), extra-bold mayúsculas 68 px (3.5 % del alto), a y≈52 %. *medido*
5. **Palabra partida a ambos lados del cuerpo**: DEEP x=146–404, WORK x=619–916; el centro queda libre para el torso y el subtítulo. *medido*
6. **Cada palabra entra con blur-in de 0.2 s en su sílaba** (offset 0.0 y +0.2 s) y salen juntas con fundido (17.8). *observado*
7. **Push-in ≈1.15× en 0.25 s** al aparecer el texto (15.3) y zoom-out en 0.3 s (16.9): el zoom dura lo que dura el concepto (≈1.6 s). *derivado*
8. **Apagar el subtítulo en las pausas** (20.2–21.3) y dejar el silencio. *observado*
9. **Sin cortes visibles**: 34.8 s en un plano; el dinamismo lo ponen las manos (3.1, 15–17, 25, 29). Posible salto en 21.37 (*derivado, no confirmado*).
10. **Salida con fundido a negro de 0.4 s** (34.4) sin CTA. *medido*

Sonido: desconocido; el piso de RMS es alto (≈ −33 dB frente a −45/−50 en v17/v18) → probable cama de música o ambiente continuo (*inferido*). No se puede confirmar whoosh en el zoom.
Color: frío teal/azul-gris, negros densos, piel cálida.
Evidencia extra de audio (derivado de audio/no_vocals.wav ya existente): pista sin voz constante a ≈ −34 dB con subidas de ≈3 dB cada ≈8 s (0.5–2, 8–10, 16–18, 24.5–26, 32–34 s) → cama musical/ambiente en bucle de ≈8 s, baja; sfx_events.json está vacío → ningún SFX discreto detectado (ni en el zoom de 15.3).
