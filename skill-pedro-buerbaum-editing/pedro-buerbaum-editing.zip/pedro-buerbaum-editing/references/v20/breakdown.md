# v20 — breakdown
**Formato propuesto** (labels.json "?"): `whiteboard_split_alterno` — título fijo, alternancia de cámara cercana a banda completa y split busto+pizarra. Justificación: 7 planos que alternan exactamente esos dos diseños (*observado*).

**Guion**: hook ('a los que nos dicen que no…', 0–4.1) → promesa ('tres columnas', 4.1–6.6) → las 3 razones del no (6.6–15.1) → segmento 1 dolor → nutrir (15.1–25.4) → segmento 2 presupuesto → guardar para oportunidades (25.4–40.2) → segmento 3 urgencia → eventos con cierre y recontacto (40.2–62.6) → cierre ('no dejes ese dinero sobre la mesa', 62.6–66). Sin CTA.

**Ritmo**: 12 escenas / 66 s = 5.5 s por escena (*derivado*). 6 cortes (5.5/min) → cambio de encuadre cada 9.4 s de media (3.4–18.2 s).

**Mediciones** (1080×1920)
- Lienzo #000000; banda full y=339–1564 (1225 px, 64 %); split y=339–1583 (65 %); esquinas rectas, sin tarjeta redondeada.
- Split ≈45 % frontal / 55 % pizarra (costura estimada y≈897–936).
- Título: sans regular blanca ≈26 px (1.4 %), x=181–901, y≈290–316, fijo.
- Subtítulo: sans regular/medium blanca con sombra, ≈38–40 px (2.0 %), 1–3 palabras (media ≈1.9), full: y=1057–1111 (56.5 %); split: sobre la costura (≈47 %). Sin palabra destacada. Sustitución seca.
- Gráficos digitales: 0. Pizarra real visible 70 % del tiempo (46.1 s).
- Transiciones: 6 cortes secos; ningún fundido, zoom digital ni SFX visible.
- Color: high-key cálido-neutro, contraste bajo-medio, sin grano.
- Sonido: desconocido (*no audible*); RMS no sugiere música clara (*inferido*).

**Técnicas destacables**
1. 0–4 hook escribiendo.
2. 6.46 split al empezar la lista.
3. 7.5–15 tabla de 3 columnas en directo.
4. 19.19 corte a cara mientras se incorpora (gesto 'elevar' 23.0).
5. 27.0 recuadro de 'PR'.
6. 43.54 cara para la táctica.
7. 62.60 corte exacto en 'pero' para el cierre.

**Reglas copiables**
- Alternar pizarra larga (12–18 s) con cara corta (3–6 s).
- Cortar en conjunciones (para / y / pero).
- Señalar o recuadrar la parte del dibujo de la que se habla en lugar de añadir gráficos.
- Mantener título fijo y subtítulo de 2 % del alto durante todo el video.
- Nota de categorías: `aroll_punch` = cambio a cámara cercana con movimiento; s11 es `aroll_caption` con encuadre split (habla sin dibujar); `title_cta` = cierre sin CTA.
