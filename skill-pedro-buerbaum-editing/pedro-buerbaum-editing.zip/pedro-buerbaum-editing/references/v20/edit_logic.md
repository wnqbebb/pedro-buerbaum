# v20 — lógica de edición (10 reglas copiables)
Formato: título fijo + alternancia cámara cercana (full) / split con pizarra. 6 cortes secos, ningún gráfico digital.

1. **Lienzo negro con banda central**: full y=339–1564 (64 % del alto); split y=339–1583 (65 %); título fijo arriba (y≈290–316, ≈26 px). *medido*
2. **Hook en acción** (0.0–4.1): empieza escribiendo en la pizarra, cámara cercana, sin mirar a lente. *observado*
3. **Mirada a cámara en la promesa**: se incorpora en 'los clasificamos en tres columnas' (4.2). *observado*
4. **Corte a split 0.1 s antes de la enumeración** (6.46 → 'decir oye…'): la pizarra entra cuando empieza la lista. *observado*
5. **Una columna por segmento**: tabla DOL | PR | URG trazada durante 'urgencia… presupuesto… dolor' (7.5–15); luego se señala/recuadra la columna de la que se habla (16.0, 27.0, 41.5). *observado ±0.75 s*
6. **Cara para el 'por qué' y la táctica**: cortes a cámara cercana en 19.19 ('para que entiendan…') y 43.54 ('tratamos de conseguir eventos'). *observado*
7. **Respiro corto**: los tramos de cara duran 3.4–6.5 s; los de pizarra 12.7–18.2 s. *derivado*
8. **Subtítulo**: sans blanca ≈38–40 px (2 %), 1–3 palabras; en full a 56.5 % del alto (y 1057–1111), en split sobre la costura (≈47 %). Sin palabra destacada. *medido/observado*
9. **Cortes en conjunciones**: 25.36 'para', 47.38 'y', 62.60 'pero' (offset 0.0 ± 0.04 s). *observado*
10. **Cierre a la cara sin CTA** (62.6–66.0): 'no puedes dejar ese dinero sobre la mesa'. *observado*

Sonido: desconocido; piso RMS ≈ −40 dB → sin evidencia clara de música (*inferido*). Sin SFX deducibles.
Color: high-key cálido-neutro, tinta azul, lienzo #000.
